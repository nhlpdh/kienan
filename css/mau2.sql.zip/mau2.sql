-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Feb 26, 2010 at 08:45 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `mau2`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_admin`
-- 

CREATE TABLE `hdc_admin` (
  `id` int(5) NOT NULL auto_increment,
  `username` varchar(20) collate utf8_unicode_ci default NULL,
  `password` varchar(40) collate utf8_unicode_ci default NULL,
  `user_mod` int(5) default NULL,
  `fullname` varchar(255) character set utf8 default NULL,
  `status` enum('false','true') character set utf8 default 'true',
  `modn` varchar(2) character set utf8 default '0',
  `email` varchar(200) character set utf8 NOT NULL,
  `ma` varchar(200) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

-- 
-- Dumping data for table `hdc_admin`
-- 

INSERT INTO `hdc_admin` VALUES (23, 'admin', 'c3284d0f94606de1fd2af172aba15bf3', NULL, 'admin', 'true', '1', 'huy_hdc@yahoo.com', NULL);
INSERT INTO `hdc_admin` VALUES (22, 'huyen', '87bf29a54cfcfefb8759e1d5d99457df', NULL, 'vuhuy', 'true', '1', 'hdc789@gmail.com', '2754032');
INSERT INTO `hdc_admin` VALUES (26, 'demo', '6c5ac7b4d3bd3311f033f971196cfa75', NULL, 'demo', 'true', '0', 'demo', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_ads`
-- 

CREATE TABLE `hdc_ads` (
  `id` int(11) NOT NULL auto_increment,
  `picture` varchar(200) character set utf8 default NULL,
  `link` varchar(200) character set utf8 default NULL,
  `stt` int(5) default NULL,
  `alignment` int(5) default NULL,
  `status` enum('false','true') character set utf8 default 'true',
  `postdate` varchar(255) character set utf8 default NULL,
  `title` varchar(200) character set utf8 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=192 ;

-- 
-- Dumping data for table `hdc_ads`
-- 

INSERT INTO `hdc_ads` VALUES (188, '1264712636_untitled.JPG', 'http://www.hdc.vn', 1, 2, 'true', '1264712636', 'hdc.vn');
INSERT INTO `hdc_ads` VALUES (189, '1264375297_1.jpg', 'http://', 1, 3, 'true', '1264375297', 'flash1');
INSERT INTO `hdc_ads` VALUES (190, '1264375310_2.jpg', 'http://', 1, 3, 'true', '1264375310', 'flash2');
INSERT INTO `hdc_ads` VALUES (187, '1264712545_1264548598_logo.jpg', 'https://www.siteground.com/', 1, 1, 'true', '1264712545', 'https://www.siteground.com/');
INSERT INTO `hdc_ads` VALUES (186, '1264732660_Untitled-5.gif', 'http://', 1, 4, 'true', '1264732660', 'banner');
INSERT INTO `hdc_ads` VALUES (191, '1264375319_3.jpg', 'http://', 1, 3, 'true', '1264375319', 'flash3');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_anh`
-- 

CREATE TABLE `hdc_anh` (
  `id` int(5) NOT NULL auto_increment,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `category` varchar(5) character set utf8 default NULL,
  `picture` varchar(200) collate utf8_unicode_ci default NULL,
  `status` enum('false','true') character set utf8 default 'true',
  `postdate` varchar(100) collate utf8_unicode_ci default NULL,
  `subCategory` varchar(5) character set utf8 default NULL,
  `solan` int(6) default '0',
  `picture2` varchar(200) character set utf8 default NULL,
  `tomtat` text character set utf8,
  `luachon` varchar(20) collate utf8_unicode_ci default NULL,
  `stt` int(10) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=570 ;

-- 
-- Dumping data for table `hdc_anh`
-- 

INSERT INTO `hdc_anh` VALUES (544, '05', '378', 'thumb_1264139146.jpg', 'true', '1264139146', '', NULL, 'goc_1264139146.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (543, '04', '378', 'thumb_1264139136.jpg', 'true', '1264139136', '', NULL, 'goc_1264139136.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (542, '03', '378', 'thumb_1264139125.jpg', 'true', '1264139125', '', NULL, 'goc_1264139125.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (541, '02', '378', 'thumb_1264139113.jpg', 'true', '1264139114', '', NULL, 'goc_1264139114.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (540, '01', '378', 'thumb_1264139103.jpg', 'true', '1264139103', '', NULL, 'goc_1264139103.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (539, '05', '377', 'thumb_1264139072.jpg', 'true', '1264139073', '', NULL, '12641390721255888567keu8.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (538, '04', '377', 'thumb_1264139061.jpg', 'true', '1264139061', '', NULL, '12641390611255888538keu5.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (537, '03', '377', 'thumb_1264139032.jpg', 'true', '1264139043', '', NULL, '12641390321255888525keu2.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (535, '01', '377', 'thumb_1264138991.jpg', 'true', '1264138991', '', NULL, '12641389911255888170keu3.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (536, '02', '377', 'thumb_1264139006.jpg', 'true', '1264139006', '', NULL, '12641390061255888511keu1.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (545, '01', '379', 'thumb_1264139228.jpg', 'true', '1264139228', '', NULL, '12641392281255888553keu7.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (546, '02', '379', 'thumb_1264139242.jpg', 'true', '1264139242', '', NULL, 'goc_1264139242.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (547, '03', '379', 'thumb_1264139253.jpg', 'true', '1264139254', '', NULL, 'goc_1264139254.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (548, '04', '379', 'thumb_1264139264.jpg', 'true', '1264139264', '', NULL, 'goc_1264139264.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (553, '02', '386', 'thumb_1264359000.jpg', 'true', '1264359000', '387', 0, 'goc_1264359000.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (552, '01', '386', 'thumb_1264358984.jpg', 'true', '1264358984', '387', 0, 'goc_1264358984.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (554, '03', '386', 'thumb_1264359017.jpg', 'true', '1264359017', '387', 0, 'goc_1264359017.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (555, '04', '386', 'thumb_1264359037.jpg', 'true', '1264359038', '387', 0, '1264359037ES1b.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (556, '05', '386', 'thumb_1264359056.jpg', 'true', '1264359056', '387', 0, 'goc_1264359056.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (557, '06', '386', 'thumb_1264359070.jpg', 'true', '1264359070', '387', 0, 'goc_1264359070.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (558, '07', '386', 'thumb_1264359090.jpg', 'true', '1264359090', '387', 0, 'goc_1264359090.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (559, '08', '386', 'thumb_1264359119.jpg', 'true', '1264359120', '387', 0, '1264359119H1.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (560, '01', '386', 'thumb_1264359341.jpg', 'true', '1264359341', '388', 0, 'goc_1264359341.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (561, '02', '386', 'thumb_1264359349.jpg', 'true', '1264359349', '388', 0, '1264359349080922180704-721-952.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (562, '03', '386', 'thumb_1264359357.jpg', 'true', '1264359357', '388', 0, '1264359356c0a4821976df69def7702fd86f26a807.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (563, '04', '386', 'thumb_1264359366.jpg', 'true', '1264359366', '388', 0, 'goc_1264359366.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (564, '05', '386', 'thumb_1264359377.jpg', 'true', '1264359377', '388', 0, '1264359377ici_xe may silver wing.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (565, '06', '386', 'thumb_1264359390.jpg', 'true', '1264359390', '388', 0, 'goc_1264359390.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (566, '07', '386', 'thumb_1264359400.jpg', 'true', '1264368414', '388', 0, '1264359400photo-28-05-08-03-28-05.jpg', NULL, NULL, 5);
INSERT INTO `hdc_anh` VALUES (567, '08', '386', 'thumb_1264359410.jpg', 'true', '1264367977', '388', 0, 'goc_1264359410.jpg', NULL, NULL, 2);

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_bodem`
-- 

CREATE TABLE `hdc_bodem` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(200) character set utf8 default NULL,
  `tong` int(5) default NULL,
  `status` enum('false','true') character set utf8 default 'true',
  `postdate` varchar(255) character set utf8 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=763 ;

-- 
-- Dumping data for table `hdc_bodem`
-- 

INSERT INTO `hdc_bodem` VALUES (762, '127.0.0.1', 25759, 'true', '1250638163');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_bottom`
-- 

CREATE TABLE `hdc_bottom` (
  `id` int(11) NOT NULL auto_increment,
  `full_intro` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

-- 
-- Dumping data for table `hdc_bottom`
-- 

INSERT INTO `hdc_bottom` VALUES (15, '<BR>\r\n<DIV style="TEXT-ALIGN: center"><STRONG>Copyright © 2009&nbsp; <A title="" href="http://websitepackage.org/" target="">Websitepackage.org</A>-&nbsp; All rights reserved.</STRONG><BR></DIV>\r\n<DIV style="TEXT-ALIGN: center">&nbsp;</DIV>');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_contact`
-- 

CREATE TABLE `hdc_contact` (
  `id` int(10) NOT NULL auto_increment,
  `fullname` varchar(255) character set utf8 default NULL,
  `address` varchar(255) character set utf8 default NULL,
  `telephone` varchar(255) character set utf8 default NULL,
  `email` varchar(200) character set utf8 default NULL,
  `title` varchar(255) character set utf8 default NULL,
  `content` text character set utf8,
  `postdate` varchar(50) character set utf8 default NULL,
  `status` enum('false','true') character set utf8 default 'false',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `hdc_contact`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_contact2`
-- 

CREATE TABLE `hdc_contact2` (
  `id` int(5) NOT NULL auto_increment,
  `full_intro` text collate utf8_unicode_ci,
  `email` varchar(200) character set utf8 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=74 ;

-- 
-- Dumping data for table `hdc_contact2`
-- 

INSERT INTO `hdc_contact2` VALUES (73, '<BR><SPAN class=short_text id=result_box><SPAN title="Mọi chi tiết xin quý khách vui lòng nhập vào form dưới đây:" style="BACKGROUND-COLOR: rgb(255,255,255)">For further information please enter the form below:</SPAN></SPAN><BR><BR>', 'huy_hdc@yahoo.com');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_download`
-- 

CREATE TABLE `hdc_download` (
  `id` int(5) NOT NULL auto_increment,
  `title` text character set utf8,
  `picture` varchar(255) character set utf8 default NULL,
  `short` text character set utf8,
  `full` text character set utf8,
  `postdate` varchar(20) character set utf8 default NULL,
  `status` enum('false','true') character set utf8 default 'true',
  `loai` varchar(100) character set utf8 default NULL,
  `link` text character set utf8,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=76 ;

-- 
-- Dumping data for table `hdc_download`
-- 

INSERT INTO `hdc_download` VALUES (74, 'test', '1264452086_114045_Huongdan_caidat_font.doc', '', '', '1264452086', 'true', '', 'http://');
INSERT INTO `hdc_download` VALUES (75, 'Aiseesoft PDF Converter Ultimate', '', '', '', '1264452207', 'true', 'true', 'http://www.aiseesoft.com/downloads/pdf-converter-ultimate.exe');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_guide`
-- 

CREATE TABLE `hdc_guide` (
  `id` int(5) NOT NULL auto_increment,
  `full` text collate utf8_unicode_ci,
  `title` varchar(200) character set utf8 NOT NULL,
  `stt` varchar(200) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=82 ;

-- 
-- Dumping data for table `hdc_guide`
-- 

INSERT INTO `hdc_guide` VALUES (79, '<SPAN class=short_text id=result_box><SPAN title="Đang cập nhật giới thiệu" style="BACKGROUND-COLOR: rgb(255,255,255)">Updating introduced</SPAN></SPAN>', 'Intro', '1');
INSERT INTO `hdc_guide` VALUES (80, '<SPAN class=short_text id=result_box><SPAN title="Đang cập nhật tuyển dụng" style="BACKGROUND-COLOR: rgb(255,255,255)">Updating Employment</SPAN></SPAN>', 'Employment', '2');
INSERT INTO `hdc_guide` VALUES (81, '<SPAN class=short_text id=result_box><SPAN title="Đang cập nhật hướng dẫn" style="BACKGROUND-COLOR: rgb(255,255,255)">Updating Guide</SPAN></SPAN>', 'Guide', '3');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_intro`
-- 

CREATE TABLE `hdc_intro` (
  `id` int(5) NOT NULL auto_increment,
  `full_intro` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=74 ;

-- 
-- Dumping data for table `hdc_intro`
-- 

INSERT INTO `hdc_intro` VALUES (1, '<span class="bodyContent" id="ctl14_ltrContent">\r\n<div>Trong khi loạt b&agrave;i về vấn nạn c&acirc;y sưa của ch&uacute;ng t&ocirc;i đang được thực hiện, s&aacute;ng sớm ng&agrave;y 17/9, c&acirc;y sưa mới hơn 7 năm tuổi trước cửa số nh&agrave; 114 Vũ Trọng Phụng (quận Thanh Xu&acirc;n, H&agrave; Nội) lại&nbsp;bị cưa trộm. C&acirc;y sưa kể tr&ecirc;n bị cắt rời l&agrave;m đ&ocirc;i rồi bị bỏ lại hiện trường, phần th&acirc;n tr&ecirc;n của c&acirc;y mắc kẹt v&agrave;o đ&aacute;m d&acirc;y c&aacute;p loằng ngoằng.</div>\r\n<div>&nbsp;</div>\r\n<div align="center"><span style="font-size: 10pt; font-family: Tahoma;"><img src="http://dantri.vcmedia.vn/Uploaded/2009/09/17/caysua_170909.jpg" alt="" /><br />\r\nHiện trường c&acirc;y sưa non bị chặt oan.</span></div>\r\n<div align="center">&nbsp;</div>\r\n<div>Theo một c&aacute;n bộ C&ocirc;ng ty C&ocirc;ng vi&ecirc;n c&acirc;y xanh H&agrave; Nội, c&acirc;y sưa n&agrave;y c&oacute; l&otilde;i sưa đỏ c&ograve;n rất nhỏ n&ecirc;n hầu như kh&ocirc;ng c&oacute; gi&aacute; trị về kinh tế, ch&iacute;nh v&igrave; thế n&ecirc;n bọn trộm mới bỏ c&acirc;y lại. Thời gian vừa qua, tr&ecirc;n địa b&agrave;n TP H&agrave; Nội từng ghi nhận nhiều c&acirc;y sưa non&nbsp;bị kẻ trộm d&ograve;m ng&oacute;, chặt oan.</div>\r\n<div>&nbsp;</div>\r\n<div>Đ&acirc;y l&agrave; vụ cưa trộm c&acirc;y sưa đỏ thứ 11 li&ecirc;n tiếp từ đầu th&aacute;ng 9 đến nay. Hiện trường vụ việc c&aacute;ch trụ sở c&ocirc;ng an quận Thanh Xu&acirc;n chưa đầy 400m.</div>\r\n<p>Như <span style="font-style: italic;">D&acirc;n tr&iacute;</span> đ&atilde; đưa tin, chiều 16/9, thiếu tướng Nguyễn Đức Nhanh, Gi&aacute;m đốc CATP đ&atilde; chỉ đạo lực lượng Cảnh s&aacute;t điều tra tội phạm về trật tự x&atilde; hội, lực lượng Cảnh s&aacute;t cơ động v&agrave; C&ocirc;ng an c&aacute;c quận huyện tr&ecirc;n địa b&agrave;n th&agrave;nh phố tập trung lập phương &aacute;n đấu tranh, ngăn chặn h&agrave;nh vi chặt ph&aacute; tr&aacute;i ph&eacute;p n&agrave;y.</p>\r\n<p>Gi&aacute;m đốc CATP y&ecirc;u cầu c&aacute;c đơn vị chuy&ecirc;n m&ocirc;n của CATP khẩn trương tập hợp chứng cứ, điều tra, l&agrave;m r&otilde; v&agrave; c&oacute; biện ph&aacute;p xử l&yacute; c&aacute;c đối tượng đ&atilde; g&acirc;y ra h&agrave;ng loạt vụ chặt ph&aacute; tr&aacute;i ph&eacute;p c&acirc;y sưa vừa qua tại H&agrave; Nội. Song song với việc điều tra, truy cứu tr&aacute;ch nhiệm những đối tượng chặt hạ c&acirc;y sưa, l&atilde;nh đạo CATP cũng y&ecirc;u cầu c&aacute;c đơn vị li&ecirc;n quan lập phương &aacute;n ngăn chặn ph&ograve;ng ngừa t&aacute;i diễn t&igrave;nh trạng n&agrave;y.</p>\r\n</span>');
INSERT INTO `hdc_intro` VALUES (2, 'Chào mừng bạn đến với website của chúng tôi, chúc quý khách một ngày may mắn và hạnh phúc');
INSERT INTO `hdc_intro` VALUES (3, '<span class="bodyContent" id="ctl14_ltrContent">\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Khi &ocirc;m cậu con trai 5 th&aacute;ng tuổi trong v&ograve;ng tay của m&igrave;nh, chị B&ugrave;i Thị Thương kh&ocirc;ng c&ograve;n nước mắt để kh&oacute;c... Chị cứ h&ocirc;n h&iacute;t cậu con trai cho thoả nỗi nhớ sau những ng&agrave;y xa c&aacute;ch. Ch&aacute;u b&eacute; 5 th&aacute;ng tuổi kh&ocirc;i ng&ocirc;, trắng trẻo to&eacute;t miệng cười, đ&ocirc;i mắt tr&ograve;n ngơ ng&aacute;c khi thấy nhiều người lạ xung quanh&hellip;</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Vụ việc xảy ra v&agrave;o trưa 8/9, chị Thương trong t&acirc;m trạng hoảng loạn t&igrave;m đến Đội CSĐT tội phạm về TTXH, C&ocirc;ng an quận Long Bi&ecirc;n tr&igrave;nh b&aacute;o việc con trai chị bị một người phụ nữ mới quen biết bắt c&oacute;c...</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Chị Thương nghẹn ng&agrave;o kể lại: Ch&aacute;u Nhật Anh sinh ra kh&ocirc;ng nhận được sự thừa nhận của người đ&agrave;n &ocirc;ng chị y&ecirc;u. Th&aacute;ng 7/2009, chị mang con đến xin t&aacute; t&uacute;c tại một ng&ocirc;i ch&ugrave;a tr&ecirc;n địa b&agrave;n quận Long Bi&ecirc;n, quyết nu&ocirc;i con một m&igrave;nh. Trong thời gian ở ch&ugrave;a, chị quen một phụ nữ t&ecirc;n l&agrave; Nguyệt.</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Ng&agrave;y 26/8, ch&aacute;u Nhật Anh bị ốm nặng, chị Thương đưa con v&agrave;o Bệnh viện Đức Giang điều trị. L&uacute;c đ&oacute;, khoảng 10h ng&agrave;y 8/9, người phụ nữ t&ecirc;n Nguyệt dắt theo một ch&aacute;u b&eacute; t&igrave;m gặp chị Thương. L&uacute;c ấy, chị Thương pha cho con một b&igrave;nh sữa rồi nhờ Nguyệt bế hộ con để tranh thủ đi mua cơm. Khi chị Thương đi ra đến h&agrave;nh lang vẫn thấy Nguyệt ăn cơm, nhưng chị Thương quay v&agrave;o th&igrave; chẳng thấy Nguyệt đ&acirc;u.</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Linh t&iacute;nh m&aacute;ch bảo chị vội chạy ra căng tin ở bệnh viện, gọi điện thoại cho một phụ nữ t&ecirc;n l&agrave; Xoan, người ở c&ugrave;ng ch&ugrave;a để li&ecirc;n lạc với Nguyệt. Khoảng 15 ph&uacute;t sau, vẫn kh&ocirc;ng thấy Xoan gọi lại, chị hỏi th&igrave; được biết Nguyệt đ&atilde; tắt m&aacute;y kh&ocirc;ng li&ecirc;n lạc được. Cứ thế, Thương chạy khắp bệnh viện rồi mếu m&aacute;o t&igrave;m con.</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-weight: bold;">H&agrave;nh tr&igrave;nh lần manh mối ch&aacute;u b&eacute;<o:p></o:p></span></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Sau khi b&aacute;o c&aacute;o Ban chỉ huy C&ocirc;ng an quận, c&aacute;c mũi c&ocirc;ng t&aacute;c của Đội CSĐT tội phạm về TTXH, C&ocirc;ng an quận Long Bi&ecirc;n đ&atilde; toả đi khắp c&aacute;c địa b&agrave;n r&agrave; so&aacute;t, đồng thời li&ecirc;n hệ với C&ocirc;ng an ở một số địa phương c&oacute; tuyến bi&ecirc;n giới về đặc điểm nhận dạng của ch&aacute;u b&eacute; bị bắt c&oacute;c...</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Đầu mối của vụ &aacute;n h&eacute; mở, khi c&aacute;c anh c&oacute; t&agrave;i liệu, trước đ&oacute; v&agrave;i ng&agrave;y, Nguyệt n&oacute;i với một số người rằng chị ta về Hưng Y&ecirc;n chơi. Tối 14/9, họ c&oacute; nguồn tin tại x&atilde; Đại Đồng, huyện Văn L&acirc;m (Hưng Y&ecirc;n), c&oacute; chị Nguyễn Thị Oanh vừa mua được một ch&aacute;u b&eacute; trai chừng 5 th&aacute;ng tuổi. L&uacute;c n&agrave;y, c&aacute;c trinh s&aacute;t đ&atilde; t&igrave;m v&agrave;o căn nh&agrave; của chị Oanh v&agrave; đưa ch&aacute;u b&eacute; về trụ sở để l&agrave;m r&otilde;.</p>\r\n</span>');
INSERT INTO `hdc_intro` VALUES (4, '<object height="140" width="180">\r\n<param name="movie" value="http://www.youtube.com/v/8f1ijAM9kps&amp;hl=en&amp;fs=1&amp;" />\r\n<param name="allowFullScreen" value="true" />\r\n<param name="allowscriptaccess" value="always" /><embed height="140" width="180" src="http://www.youtube.com/v/8f1ijAM9kps&amp;hl=en&amp;fs=1&amp;" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true"></embed></object>');
INSERT INTO `hdc_intro` VALUES (5, '5');
INSERT INTO `hdc_intro` VALUES (6, '<p>6dfgj fg</p>\r\n<br />');
INSERT INTO `hdc_intro` VALUES (7, '<p>7dgj</p>\r\n<br />');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_member2`
-- 

CREATE TABLE `hdc_member2` (
  `id` int(10) NOT NULL auto_increment,
  `fullname` varchar(255) character set utf8 default NULL,
  `address` varchar(255) character set utf8 default NULL,
  `telephone` varchar(255) character set utf8 default NULL,
  `email` varchar(200) character set utf8 default NULL,
  `postdate` varchar(50) character set utf8 default NULL,
  `status` enum('false','true') character set utf8 default 'false',
  `username` varchar(255) character set utf8 default NULL,
  `password` varchar(255) collate utf8_unicode_ci default NULL,
  `website` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

-- 
-- Dumping data for table `hdc_member2`
-- 

INSERT INTO `hdc_member2` VALUES (18, 'vuhuy', 'mmm', 'mmm', 'mmm', '1222367241', 'true', 'mmm', 'c4efd5020cb49b9d3257ffa0fbccc0ae', 'mmm');
INSERT INTO `hdc_member2` VALUES (17, 'vuhuy', 'hhh', 'hhh', 'hhh', '1222367126', 'true', 'hhh', 'a3aca2964e72000eea4c56cb341002a4', 'hhh');
INSERT INTO `hdc_member2` VALUES (19, 'kkk', 'hhhhhhhhhhhhhhhhhhh', 'hhhhhhhhhhhhhhhhh', 'hhhhhhhhhhhhhhhhhhh', '1223511935', 'false', 'kkk', 'kkk', 'hhhhhhhhhhhhhhhhhhhhh');
INSERT INTO `hdc_member2` VALUES (20, 'aaaaaaaaaa', 'aaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaa', '1223512693', 'true', 'aaa', 'aaa', 'aaa');
INSERT INTO `hdc_member2` VALUES (21, 'eeee', 'eeeeeeeeee', 'eeeeeeeeeeeeeeeeeee', 'eeeeeeeeeeeeeeeeeee', '1223512810', 'true', 'eee', '670da91be64127c92faac35c8300e814', 'eee');
INSERT INTO `hdc_member2` VALUES (22, 'lll', 'lll', 'lll', 'lll', '1223517474', 'true', 'lll', 'bf083d4ab960620b645557217dd59a49', 'lll');
INSERT INTO `hdc_member2` VALUES (23, 'vuhuy', 'hksdjgs', 'hsklgsdg', 'huy_hdc@yahoo.com', '1223518061', 'true', 'huy', 'e77f82936e7e4577e2defed037208b7f', '1234');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_menu_anh`
-- 

CREATE TABLE `hdc_menu_anh` (
  `id` int(5) NOT NULL auto_increment,
  `category` varchar(100) collate utf8_unicode_ci NOT NULL default '',
  `status` enum('true','false') collate utf8_unicode_ci NOT NULL default 'true',
  `stt` int(5) NOT NULL default '0',
  `parent` int(5) default '0',
  `picture` varchar(200) collate utf8_unicode_ci NOT NULL,
  `picture2` varchar(200) character set utf8 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=390 ;

-- 
-- Dumping data for table `hdc_menu_anh`
-- 

INSERT INTO `hdc_menu_anh` VALUES (322, 'Gường bệnh nhân Inox', 'true', 3, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (323, 'Sản xuất tại JAPAN', 'true', 1, 290, '', '');
INSERT INTO `hdc_menu_anh` VALUES (324, 'Sản xuất tại USA', 'true', 2, 290, '', '');
INSERT INTO `hdc_menu_anh` VALUES (332, 'Ghế Inox', 'true', 2, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (333, 'Tủ thuốc,Tủ Inox', 'true', 4, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (334, 'Xe đẩy Inox,Bàn tiêm', 'true', 5, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (335, 'Thùng rác Y tế', 'true', 6, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (336, 'Bục lên xuống bàn đẻ', 'true', 7, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (337, 'Cọc truyền huyết thanh Inox', 'true', 8, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (342, 'Bồn rửa tay', 'true', 9, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (379, 'Landscape', 'true', 3, 0, 'thumb_1264138919.jpg', '12641389191255888553keu7.jpg');
INSERT INTO `hdc_menu_anh` VALUES (378, 'Animals', 'true', 2, 0, 'thumb_1264138894.jpg', 'goc_1264138894.jpg');
INSERT INTO `hdc_menu_anh` VALUES (377, 'Flowers', 'true', 4, 0, 'thumb_1264138872.jpg', '12641388721255888170keu3.jpg');
INSERT INTO `hdc_menu_anh` VALUES (388, 'Motorbikes', 'true', 2, 386, 'thumb_1264358938.jpg', '1264358938080831193537-895-450.jpg');
INSERT INTO `hdc_menu_anh` VALUES (387, 'Car', 'true', 1, 386, 'thumb_1264358897.jpg', 'goc_1264358897.jpg');
INSERT INTO `hdc_menu_anh` VALUES (386, 'Car - Motorbikes', 'true', 1, 0, 'thumb_1264358848.jpg', 'goc_1264358848.jpg');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_menu_product`
-- 

CREATE TABLE `hdc_menu_product` (
  `id` int(5) NOT NULL auto_increment,
  `category` varchar(100) collate utf8_unicode_ci NOT NULL default '',
  `status` enum('true','false') collate utf8_unicode_ci NOT NULL default 'true',
  `stt` int(5) NOT NULL default '1',
  `parent` int(5) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=353 ;

-- 
-- Dumping data for table `hdc_menu_product`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_menu_product2`
-- 

CREATE TABLE `hdc_menu_product2` (
  `id` int(5) NOT NULL auto_increment,
  `category` varchar(100) collate utf8_unicode_ci NOT NULL default '',
  `status` enum('true','false') collate utf8_unicode_ci NOT NULL default 'true',
  `stt` int(5) NOT NULL default '1',
  `parent` int(5) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=300 ;

-- 
-- Dumping data for table `hdc_menu_product2`
-- 

INSERT INTO `hdc_menu_product2` VALUES (206, 'Tập đoàn Tài chính', 'true', 1, 182);
INSERT INTO `hdc_menu_product2` VALUES (269, 'Political', 'true', 1, 0);
INSERT INTO `hdc_menu_product2` VALUES (276, 'Business', 'true', 2, 0);
INSERT INTO `hdc_menu_product2` VALUES (279, 'Domestic politics', 'true', 1, 269);
INSERT INTO `hdc_menu_product2` VALUES (280, 'Political world', 'true', 2, 269);
INSERT INTO `hdc_menu_product2` VALUES (281, 'Social', 'true', 5, 0);
INSERT INTO `hdc_menu_product2` VALUES (282, 'Sports', 'true', 3, 0);
INSERT INTO `hdc_menu_product2` VALUES (283, 'Travel', 'true', 8, 0);
INSERT INTO `hdc_menu_product2` VALUES (284, 'Education', 'true', 5, 0);
INSERT INTO `hdc_menu_product2` VALUES (285, 'Entertainment', 'true', 6, 0);
INSERT INTO `hdc_menu_product2` VALUES (286, 'Culture', 'true', 4, 0);
INSERT INTO `hdc_menu_product2` VALUES (287, 'football', 'true', 1, 282);
INSERT INTO `hdc_menu_product2` VALUES (288, 'Tennis', 'true', 2, 282);
INSERT INTO `hdc_menu_product2` VALUES (289, 'Other Sports', 'true', 3, 282);
INSERT INTO `hdc_menu_product2` VALUES (290, 'stock market', 'true', 1, 276);
INSERT INTO `hdc_menu_product2` VALUES (291, 'Business', 'true', 2, 276);
INSERT INTO `hdc_menu_product2` VALUES (292, 'market', 'true', 3, 276);
INSERT INTO `hdc_menu_product2` VALUES (293, 'music', 'true', 1, 285);
INSERT INTO `hdc_menu_product2` VALUES (294, 'movies', 'true', 2, 285);
INSERT INTO `hdc_menu_product2` VALUES (295, 'fashion', 'true', 3, 285);
INSERT INTO `hdc_menu_product2` VALUES (296, 'European', 'true', 1, 283);
INSERT INTO `hdc_menu_product2` VALUES (297, 'Asia', 'true', 2, 283);
INSERT INTO `hdc_menu_product2` VALUES (298, 'Americas', 'true', 3, 283);
INSERT INTO `hdc_menu_product2` VALUES (299, 'Australia', 'true', 4, 283);

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_product`
-- 

CREATE TABLE `hdc_product` (
  `id` int(5) NOT NULL auto_increment,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `category` int(5) default NULL,
  `picture` varchar(200) collate utf8_unicode_ci default NULL,
  `price` varchar(255) character set utf8 default NULL,
  `special` varchar(20) character set utf8 default NULL,
  `full` longtext character set utf8,
  `status` enum('false','true') character set utf8 default 'true',
  `postdate` varchar(100) collate utf8_unicode_ci default NULL,
  `discount` varchar(20) character set utf8 default NULL,
  `tomtat` text collate utf8_unicode_ci,
  `subCategory` varchar(5) character set utf8 default NULL,
  `solan` int(6) default '1',
  `picture2` varchar(200) character set utf8 default NULL,
  `luachon` varchar(20) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=514 ;

-- 
-- Dumping data for table `hdc_product`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_product2`
-- 

CREATE TABLE `hdc_product2` (
  `id` int(5) NOT NULL auto_increment,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `category` varchar(5) character set utf8 default NULL,
  `picture` varchar(200) collate utf8_unicode_ci default NULL,
  `price` varchar(255) character set utf8 default NULL,
  `special` varchar(20) character set utf8 default NULL,
  `full` longtext collate utf8_unicode_ci,
  `status` enum('false','true') character set utf8 default 'true',
  `postdate` varchar(100) collate utf8_unicode_ci default NULL,
  `discount` varchar(20) character set utf8 default NULL,
  `tomtat` text collate utf8_unicode_ci,
  `subCategory` varchar(5) character set utf8 default NULL,
  `solan` int(6) default '0',
  `picture2` varchar(200) character set utf8 default NULL,
  `luachon` varchar(20) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=408 ;

-- 
-- Dumping data for table `hdc_product2`
-- 

INSERT INTO `hdc_product2` VALUES (402, 'LIB 1-1 VIE – Doha dream over for Vietnam', '282', 'thumb_1264447251.jpg', '', 'true', '<p>Vietnam&rsquo;s slim hopes of reaching the 2011 AFC Asian Cup ended on Wednesday as Henrique Calisto&rsquo;s side shared a 1-1 draw with Lebanon in a Group D match at Saida Municipal Stadium.</p>\r\n<p>Lebanon took the lead after 20 minutes through Mahmoud El Ali with a first-time volley from inside the area before Pham Thanh Luong levelled the scores for Vietnam in the 40th minute.Thanh Luong then missed a glorious chance to claim a dramatic late winner as the home side held on for their first point of the campaign.</p>\r\n<p>Lebanon began the game well and controlled proceedings for the opening 20 minutes before they eventually opened the scoring.</p>\r\n<p>Midfielder Ali El Atat knocked in a free kick from the left which lanky striker El Ali met with a powerful volley that found the back of the net via the woodwork.</p>\r\n<p>The goal seemed to spur Vietnam into life as they pressed for an immediate reply and Le Tan Tai went close six minutes later with a useful strike that flew just wide of the left upright.</p>\r\n<p>Lebanon came close to doubling their advantage in the 31st minute when Hassan Matouk drove into the area but was unfortunate to see his powerful strike smack the post.</p>\r\n<p>However, Vietnam equalised five minutes before the break when Thanh Luong smartly controlled the ball on the edge of the area before firing a left foot shot beyond Elias Freije and into the far corner.</p>\r\n<p>Vietnam came close to a second goal two minutes later when substitute midfielder Phan Thanh Hung struck an effort from distance that rose just over the crossbar as the first half ended one apiece.</p>\r\n<p>The tempo of the encounter dropped in the second period. Nguyen Vu Phong saw a decent effort turned behind by Freije for a corner on the hour mark and Lebanon threatened two minutes later when El Ali broke into the box bit shot wide.</p>\r\n<p>Vietnam continued to pressure the hosts throughout the second 45 minutes but they failed to create any clear chances as the Lebanon defence held out admirably.</p>\r\n<p>However, the visitors should have claimed the points with two minutes remaining when Lebanon goalkeeper Freije failed to clear a cross and the ball fell to Thanh Luong but he somehow missed the target with the goal at his mercy</p>', 'true', '1264727800', 'true', 'Vietnam’s slim hopes of reaching the 2011 AFC Asian Cup ended on Wednesday as Henrique Calisto’s side shared a 1-1 draw with Lebanon<br>', '287', 0, '1264447251images175034_lebanon20100107134123.jpg', '');
INSERT INTO `hdc_product2` VALUES (395, 'Taiwan''''''''s Fubon Life cleared to set up Vietnam office', '286', 'thumb_1264446586.jpg', '', 'true', '<p>Fubon Life Assurance Co. Ltd. has been approved by the Financial Supervisory Commission, Taiwan*s regulator, to set up a new branch in Vietnam.<br />\r\n<br />\r\nFubon Life will be the second Taiwanese life insurance company to set up operations in Vietnam, said the regulator in a statement. Cathay Life Insurance Co. Ltd. was the first Taiwanese insurance company to open a life insurance branch in Vietnam.<br />\r\n<br />\r\nFubon Insurance Co. Ltd., a nonlife affiliate of Fubon Life, already has a presence in Vietnam*s Ho Chi Minh City and Hanoi. The life insurer*s Vietnam operation will be based in Hanoi and will set up a branch in Ho Chi Minh City, according to the FSC.<br />\r\n<br />\r\nFubon Life declined to comment on its products, distribution and business plan for the Vietnam office, which is still subject to regulatory approval in Vietnam.<br />\r\n<br />\r\nThe life insurer is eyeing Vietnam*s growing business potential, supported by the country*s fast economic development, according to the FSS.<br />\r\n<br />\r\nVietnam will be Fubon Life*s first independent overseas branch. In China, Fubon Life and Fubon Insurance, both insurance subsidiaries of Taiwanese financial conglomerate Fubon Financial Holding, formed a 50-50 nonlife joint venture in the southeastern coastal city of Xiamen.</p>', 'true', '1264727969', '', 'Fubon Life Assurance has been approved by the Financial Supervisory Commission, Taiwan*s regulator, to set up a new branch in Vietnam.<br>', '', 0, 'goc_1264446586.jpg', '');
INSERT INTO `hdc_product2` VALUES (396, 'HP to launch music service in Europe', '276', 'thumb_1264446699.jpg', '', 'true', '<p>Hewlett-Packard, the world*s biggest maker of PCs, will launch a digital music service across key European markets on Monday, hoping to benefit from consumers* rising appetite for new types of music download services.</p>\r\n<p>The MusicStation service will be preloaded on 16 of HP*s personal computer models in Britain, France, Germany, Italy, Spain, Sweden, Switzerland, Netherlands, Belgium and Austria.</p>\r\n<p>The service has been developed and is managed by British digital music firm Omnifone. HP runs a similar service in United States with RealNetworks* Rhapsody.</p>\r\n<p>Such new subscription services helped to lift sales of digital music 12 percent last year to $4.2 billion, industry trade body IFPI said last week.</p>\r\n<p>&quot;As the world*s biggest PC vendor, HP has huge opportunity to create a viable competitor to iTunes due to its scale,&quot; said Rob Lewis, chief executive of Omnifone.</p>\r\n<p>Apple*s iTunes -- with a pay-per-download business model -- is the leading digital music distributor.</p>\r\n<p>Consumers pay around 10 euros ($14.13) a month for access to all music in HP*s service. They can try the service for free for 14 days, and keep 10 tracks each month.</p>\r\n<p>Across the Europe, Middle East and Africa region HP sold around 20 million personal computers last year, according to analysts, slightly ahead of Acer.</p>\r\n<p>&quot;With its huge scale and user base, HP*s 10-country introduction ... will help encourage legitimate access to digital music content,&quot; Rob Wells, Universal Music*s digital music chief, said in a statement.</p>\r\n<p>Global recorded music sales fell around 10 percent in 2009 as rampant illegal downloading continued to eat into legitimate digital and physical sales, according to IFPI. It estimates that around 95 percent of the music downloaded in 2009 was illegal.</p>', 'true', '1264727948', '', 'Hewlett-Packard, the world*s biggest maker of PCs, will launch a digital music service across key European markets on Monday.<br>', '291', 0, '1264446699r322546415.jpg', '');
INSERT INTO `hdc_product2` VALUES (397, 'Vietnam asks companies to sell U.S. dollars to banks', '269', 'thumb_1264446779.jpg', '', '', '<p style="text-align: justify">Vietnam&rsquo;s government has asked seven state-owned companies to &ldquo;immediately sell&rdquo; U.S. dollars to banks in order to ease a dollar shortage and meet currency demands, according to a statement on the government&rsquo;s Web site.</p>\r\n<p style="text-align: center">Seven companies including Vietnam Oil &amp; Gas Group, Vietnam National Coal-Mineral Industries Group, and Vietnam Airlines Corp. were asked to sell the currency to the nation&rsquo;s lenders amid &ldquo;unbalanced dollar supply and demand&rdquo; in the foreign- currency market, according to the statement.</p>\r\n<p style="text-align: justify">&ldquo;This is an important guidance of the government to handle the situation that major collecting foreign-currency sources such as export, remittances, foreign investment and tourism are declining while demands for currency is still very high,&rdquo; the government said in the statement.</p>\r\n<p style="text-align: justify">Vietnam&rsquo;s central bank has been struggling to ease a dollar shortage that has extended the gap between official and black- market exchange rates. That&rsquo;s meant companies have been forced to pay more on the black market for the U.S. dollars they need to purchase raw materials, machines and other foreign goods.</p>\r\n<p style="text-align: justify">Policy makers have devalued the reference rate for trading and narrowed the daily trading band for the nation&rsquo;s currency the dong against the U.S. dollar.</p>\r\n<p style="text-align: justify">Soaring demand, especially from small-sized companies, plus dollar speculation has made the foreign-currency market &ldquo;more tense,&rdquo; the government said in the statement.</p>\r\n<p style="text-align: justify">The official exchange rate of the Vietnamese dong as of late yesterday was 18,475 a dollar, according to Bloomberg data. This compares with a black-market rate of about 19,530 per dollar, according to a telephone information service run by state-owned Vietnam Post &amp; Telecommunications.</p>', 'true', '1264446779', '', 'Vietnam’s government has asked 7 state-owned companies to “immediately sell” U.S. dollars to ease a dollar shortage and meet currency demands.<BR>', '279', 0, '1264446779foreign-currency-and-coins-by-bradipo20091228154741200912281550162009122815510520091228155122.jpg', '');
INSERT INTO `hdc_product2` VALUES (398, 'Brad Pitt and Angelina Jolie no more as actors ‘agree to split’', '286', 'thumb_1264446875.jpg', '', 'true', '<p>The Hollywood actors Brad Pitt and Angelina Jolie have signed papers paving the way for a legal separation with joint custody of their six children, it was reported last night.<br />\r\n<br />\r\nThe couple, known as Brangelina, have been together since shooting the thriller Mr and Mrs Smith five years ago. They are said to have agreed that the children will live with Jolie.<br />\r\n<br />\r\nThe couple are not married; they said they would marry only when American homosexuals were also able to wed. Even so, documents were filed with a Los Angeles lawyer earlier this month to help with a smooth separation, unnamed sources told the News of the World. Pitt and Jolie will keep all the money they have earned, which Forbes estimates at more than $100m (&pound;62m) each.<br />\r\n<br />\r\nPitt, 46, will have full access to their three biological children, Shiloh and the twins Knox and Vivienne, as well as three adopted children, Maddox, from Cambodia, Zahara, from Ethiopia, and Pax, from Vietnam. All have the surname Jolie-Pitt.<br />\r\n<br />\r\nYesterday associates of both actors declined to comment, one saying it was a &ldquo;private matter&rdquo;.<br />\r\n<br />\r\nThe News of the World says the lawyers, based in Beverly Hills, have cleared the path for an announcement that has been the subject of rumours for many months.<br />\r\n<br />\r\nLast week National Enquirer magazine carried a story that Pitt and Jolie had a final explosive row at a New York restaurant called the Alto on January 6.<br />\r\n<br />\r\nIt claimed that Pitt staged the six-hour dinner as an intervention to persuade Jolie, 34, to get psychiatric help. It alleged that she had suffered depression since the death of her mother from ovarian cancer three years ago, since when Jolie&rsquo;s weight has dropped dramatically. It also claimed she had made a suicide attempt.<br />\r\n<br />\r\nThe magazine said that after that stormy night, the couple agreed their relationship was over and &ldquo;their focus is now on making a smooth transition for their children&rdquo;.<br />\r\n<br />\r\nPitt and Jennifer Aniston, 40, his former wife, were seen backstage together at the Haiti telethon in Los Angeles on Friday while Jolie was in New York promoting her next film, Salt.</p>', 'true', '1264727863', 'true', 'The couple have reportedly signed papers paving the way for a legal separation with joint custody of their children.', '', 0, '1264446875Brad-Pitt-and-Angelina-Jolie120100124154113.jpg', '');
INSERT INTO `hdc_product2` VALUES (399, 'Lee Nguyen returning to Vietnam', '282', 'thumb_1264446936.jpg', '', 'true', '<p style="text-align: justify;">After failed contract negotiations with MLS, Lee Nguyen has decided to return to the V-League and continue playing for Hoang Anh Gia Lai, even though the midfielder*s intentions were to come back to play in the United States.</p>\r\n<p style="text-align: justify;">&quot;The contract that the league offered was just too low for anybody to really consider coming back to,&quot; Nguyen told Yanks-Abroad.<br />\r\n<br />\r\nBecause of MLS*s single entity structure, players and agents negotiate with the league instead of specific teams.<br />\r\n<br />\r\n&quot;Obviously there were teams that were interested and [FC] Dallas was one in particular,&quot; said Nguyen.<br />\r\n<br />\r\nFC Dallas was widely speculated to make a move for the Texas native, but because of failed negotiations with the league, a move to Pizza Hit Park did not occur.<br />\r\n<br />\r\nThe young midfielder had interest from many clubs in MLS. The New York Red Bulls had the first shot at signing Nguyen because of the MLS Allocation Order set up, though other teams could trade for their spot.<br />\r\n<br />\r\n&quot;So it kind of sucks on that end when a club wants you but they have no real power or say in it,&quot; said the 23-year-old American.<br />\r\n<br />\r\nComing out of high school, Nguyen was also once a target for MLS, but the Dallas native chose to enroll at Indiana University instead. After impressing at the 2005 FIFA World Youth Championships, the midfielder signed with PSV Eindhoven in the Netherlands.<br />\r\n<br />\r\nAfter a stint with Randers FC of the Danish Superliga, Nguyen surprised many by signing with his current team, Hoang Anh Gia Lai of Vietnam in 2009.<br />\r\n<br />\r\nNguyen and Hoang Anh Gia Lai kick off the V-League season on January 31st against Khanh Hoa.</p>', 'true', '1264727853', 'true', 'After failed contract negotiations with MLS, Lee Nguyen has decided to return to the V-League and continue playing for Hoang Anh Gia Lai.<br>', '289', 0, '12644469363202010012314521120100123145320.jpg', '');
INSERT INTO `hdc_product2` VALUES (400, '“Dung Dot” unnamed in Oscar shortlist', '286', 'thumb_1264447035.jpg', '', 'true', '<p><st1:country-region w:st="on"><st1:place w:st="on">Vietnam</st1:place></st1:country-region>&rsquo;s representative at the 2010 Oscar &ldquo;Dung Dot&rdquo; is rejected from a shortlist of movies entering the next round for The Best Foreign Film category.</p>\r\n<p>The <st1:place w:st="on"><st1:placetype w:st="on">Academy</st1:placetype> of <st1:placename w:st="on">Motion Picture Arts</st1:placename></st1:place> and Sciences has announced nine movies which will go to the next round of the 82nd Academy Award. All of the selected films have won many prestigious awards.</p>\r\n<p>Among them are Germany&rsquo;s &ldquo;The White Ribbon&rdquo; (The Golden Globe Award 2010 for the Best Foreign Film), France&rsquo;s &ldquo;Un Prophete&rdquo; (The winner of the Grand Award of the jury of the Cannes Film Festival 2009 and the nominee of the Golden Palm Award 2009 and the Golden Globe Award 2010) and Peru&rsquo;s &ldquo;The Milk of Sorrow&rdquo; (Golden Bear Award and the FIPRESCI Prize at the Berlin Film Festival 2009). These are the most outstanding foreign movies at Oscar 2010.<o:p><br />\r\n</o:p></p>\r\n<p>The remaining films are representatives of <st1:country-region w:st="on">Argentina</st1:country-region> (El Secreto de Sus Ojos), <st1:country-region w:st="on">Australia</st1:country-region> (Samson &amp; Delilah), <st1:country-region w:st="on">Bulgaria</st1:country-region> (The World Is Big and Salvation Lurks Around the Corner), <st1:country-region w:st="on">Israel</st1:country-region> (Ajami), <st1:country-region w:st="on">Kazakhstan</st1:country-region> (Kelin) and the <st1:place w:st="on"><st1:country-region w:st="on">Netherlands</st1:country-region></st1:place> (Winer in Wartime).<o:p><br />\r\n</o:p></p>\r\n<p>It is a surprise that notable movies like <st1:country-region w:st="on">Canada</st1:country-region>&rsquo;s &ldquo;I Killed My Mother&rdquo;, <st1:country-region w:st="on">China</st1:country-region>&rsquo;s &ldquo;Forever Enthralled&rdquo;, <st1:country-region w:st="on">South Korea</st1:country-region>&rsquo;s &ldquo;Mother&rdquo; and <st1:place w:st="on"><st1:country-region w:st="on">Romania</st1:country-region></st1:place>&rsquo;s &ldquo;Police, Adjective&rdquo; were rejected.<o:p><br />\r\n</o:p></p>\r\n<p>The Academy Award 2010 ceremony will take place in <st1:place w:st="on"><st1:city w:st="on">Los Angeles</st1:city>, <st1:country-region w:st="on">USA</st1:country-region></st1:place> on March 7.</p>', 'true', '1264727836', 'true', 'Vietnam’s representative at the 2010 Oscar “Dung Dot” is rejected from a shortlist of movies entering the next round for The Best Foreign Film category<br>', '', 0, '1264447035images1912302_120100122104807.jpg', '');
INSERT INTO `hdc_product2` VALUES (401, 'Miss Vietnam turns heads on catwalk', '286', 'thumb_1264447128.jpg', '', 'true', '<p>Miss Vietnam 2008, Thuy Dung showed off the appealing beauty of twenty-something girl sporting a long, black, hairdo. She walked among super models like Thanh Hang, Lan Huong, Xuan Thu and more in a recent fashion show at the Caravelle Hotel in Ho Chi Minh City.</p>\r\n<p style="text-align: center;"><img alt="" src="http://i.dtinews.vn/stores/news_dataimages/anhpt/012010/18/22/Untitled.jpg" /></p>\r\n<p style="text-align: center;"><img alt="" src="http://i.dtinews.vn/stores/news_dataimages/hoainguyen/012010/16/09/420100116090946.jpg" /><span style="color: black; font-family: Arial;"><em><font size="2"><br />\r\n</font></em></span></p>\r\n<p style="text-align: center;"><em>Thuy Dung is now more confident in fashion shows</em></p>\r\n<p style="text-align: center;"><img alt="" src="http://i.dtinews.vn/stores/news_dataimages/hoainguyen/012010/16/09/520100116090947.jpg" /></p>\r\n<p style="text-align: center;"><em>Looking more alluring with long, black hair</em><span style="color: black; font-family: Arial;"><font size="2"><br />\r\n</font></span></p>\r\n<p style="text-align: center;"><img alt="" src="http://i.dtinews.vn/stores/news_dataimages/hoainguyen/012010/16/09/320100116090947.jpg" /></p>\r\n<p style="text-align: center;"><img alt="" src="http://i.dtinews.vn/stores/news_dataimages/hoainguyen/012010/16/09/620100116090948.jpg" /></p>\r\n<p style="text-align: center;"><img alt="" src="http://i.dtinews.vn/stores/news_dataimages/hoainguyen/012010/16/09/120100116090948.jpg" /></p>\r\n<p style="text-align: center;"><em>Model Thanh Hang</em></p>\r\n<p style="text-align: center;"><img alt="" src="http://i.dtinews.vn/stores/news_dataimages/hoainguyen/012010/16/09/720100116090949.jpg" /></p>\r\n<p style="text-align: center;"><em>Lan Huong, Top 5 Miss Model of the world 2009</em></p>\r\n<p style="text-align: center;"><img alt="" src="http://i.dtinews.vn/stores/news_dataimages/hoainguyen/012010/16/09/820100116090949.jpg" /></p>\r\n<p style="text-align: center;"><em>Model Xuan Thu</em></p>\r\n<p style="text-align: center;"><img alt="" src="http://i.dtinews.vn/stores/news_dataimages/hoainguyen/012010/16/09/1120100116090950.jpg" /></p>\r\n<p style="text-align: center;"><em>Model Anh Tuan</em></p>\r\n<p style="text-align: center;"><img alt="" src="http://i.dtinews.vn/stores/news_dataimages/hoainguyen/012010/16/09/1020100116090950.jpg" /></p>\r\n<p style="text-align: center;"><em>Model Quang Thinh</em></p>', 'true', '1264727813', 'true', 'Thuy Dung showed off the appealing beauty of twenty-something girl sporting a long, black, hairdo<br>', '', 0, '1264447128Untitled.jpg', '');
INSERT INTO `hdc_product2` VALUES (403, 'Air transport industry sees record drop in demand', '269', 'thumb_1264729516.jpg', '', 'true', '<p>The international air transport industry ended 2009 with the largest ever post-war decline, according to newly released statistics by the International Air Transport Association (IATA). <br />\r\n<br />\r\n&ldquo;In terms of demand, 2009 goes into the history books as the worst year the industry has ever seen. We have permanently lost 2.5 years of growth in passenger markets and 3.5 years of growth in the freight business,&rdquo; said Giovanni Bisignani, IATA&rsquo;s Director General and CEO.<br />\r\n<br />\r\nPassenger demand for the full year was down 3.5% with an average load factor of 75.6%. Freight showed a full-year decline of 10.1% with an average load factor of 49.1%.<br />\r\n<br />\r\n&ldquo;Revenue improvements will be at a much slower pace than the demand growth that we are starting to see. Profitability will be even slower to recover and airlines will lose an expected US$5.6 billion in 2010,&rdquo; said Bisignani.<br />\r\n<br />\r\nInternational passenger capacity fell 0.7% in December 2009 while freight capacity grew 0.6% above December 2008 levels. Yields have started to improve with tighter supply-demand conditions in recent months, but they remained 5-10% down on 2008 levels.<br />\r\n<br />\r\nSeasonally adjusted demand figures for December compared to November 2009 indicate a 1.6% rise in passenger traffic while freight remained basically flat with a 0.2% decline.<br />\r\n<br />\r\n&ldquo;The industry starts 2010 with some enormous challenges. The worst is behind us, but it is not time to celebrate. Adjusting to 2.5-3.5 years of lost growth means that airlines face another spartan year focused on matching capacity carefully to demand and controlling costs,&rdquo; added Bisignani.<br />\r\n<br />\r\n&ldquo;We also face a renewed challenge on security as a result of the events of 25 December 2009. We agreed that governments and industry must cooperate and we are preparing for a meeting in the coming weeks to follow-up on our recommendations which focused on finding more efficient ways to implement intelligence-driven and risk-based security measures,&rdquo; said Bisignani.<br />\r\n<br />\r\n&ldquo;Governments and industry are aligned in the priority that we place on security. But the cost of security is also an issue. Globally, airlines spend US$5.9 billion a year on what are essentially measures concerned with national security. This is the responsibility of governments, and they should be picking up the bill,&rdquo; said Bisignani. <br />\r\n<br />\r\nIATA represents some 230 airlines comprising 93% of scheduled international air traffic.</p>', 'true', '1264729516', 'true', 'The air transport industry ended 2009 with the largest ever post-war decline, according to the International Air Transport Association.', '280', 0, 'goc_1264729516.jpg', '');
INSERT INTO `hdc_product2` VALUES (404, 'Obama wants nationwide high-speed rail system', '269', 'thumb_1264729579.jpg', '', 'true', '<p>California will get $2.3 billion and Florida $1.3 billion to help build high-speed passenger-train service, the biggest winners among 31 states sharing $8 billion in rail grants from the U.S. economic stimulus package.<br />\r\n<br />\r\nPresident Barack Obama will be in Tampa today at an event to announce the awards, most of which will go toward developing or laying the groundwork for 13 new high-speed rail corridors across the country, the administration said in a statement.<br />\r\n<br />\r\nThe funding, from the $787 billion stimulus plan approved last year, is one of a number of programs Obama will lay out in coming weeks aimed at spurring jobs, the administration said. Vice President Joseph Biden, who commuted by Amtrak between Delaware and Washington when he was a senator, will travel with Obama for the announcement at a town hall-style meeting.<br />\r\n<br />\r\n&ldquo;There&rsquo;s no reason Europe or China should have the fastest trains,&rdquo; Obama said yesterday in his State of the Union speech, citing Florida&rsquo;s rail development. &ldquo;There are projects like that all across this country that will create jobs and help move our nation&rsquo;s goods, services and information.&rdquo;<br />\r\n<br />\r\nHigh-speed rail funding in the stimulus may improve &ldquo;terrible&rdquo; U.S. passenger-train service, Biden told a meeting of state governors at the White House in June.<br />\r\n<br />\r\nAmtrak&rsquo;s Acela trains, made by Alstom SA and Bombardier Inc., operate on the Northeast Corridor at an average speed of about 83 miles per hour (134 kph), including time spent at stops and slowing for curves, said Steven Kulm, an Amtrak spokesman. The trains reach a speed of 150 mph, Kulm said.<br />\r\n<br />\r\nBullet Trains<br />\r\n<br />\r\nBy comparison, Central Japan Railway Co.&rsquo;s Shinkansen &ldquo;bullet trains&rdquo; run at 168 mph, according to the company&rsquo;s Web site. Societe Nationale des Chemins de Fer Francais, the French state railroad company, can run its TGV trains at 200 miles mph, according to its Web site. Shanghai spent $1.25 billion building the world&rsquo;s fastest train in commercial operation, a 267 mph magnetic-levitation ride to its main airport.<br />\r\n<br />\r\nA small portion of the $8 billion will go to improvements in existing rail lines, including $17 million to upgrade Burlington Northern Santa Fe Corp. tracks in Iowa, according to the White House.<br />\r\n<br />\r\nThe U.S. will give $1.1 billion for a line connecting Chicago and St. Louis, according to a White House. Amtrak&rsquo;s Northeast Corridor between Washington and Boston will get $112 million.<br />\r\n<br />\r\nOther corridors receiving high-speed rail money include lines between Minneapolis and Chicago; Charlotte, North Carolina and Washington; Seattle and Eugene, Oregon; Cleveland and Cincinnati; Detroit and Chicago; New Haven, Connecticut, and St. Albans, Vermont; New York and Buffalo, New York; Portland and Brunswick, Maine; and Philadelphia and Pittsburgh.<br />\r\n<br />\r\nApplications Surge<br />\r\n<br />\r\nThe Federal Railroad Administration said it received 45 applications requesting $50 billion in aid, and delayed the awards from last year to handle a greater number of requests than expected.<br />\r\n<br />\r\n&ldquo;It looks to me like they&rsquo;re doing it right,&rdquo; Robert Yaro, president of the Regional Plan Association in New York, said in an interview before the White House announced the spending details. &ldquo;They&rsquo;re front-loading investment in some corridors that are ready to go. Certainly Chicago and Los Angeles and to a lesser degree the Florida project have the transit links and walkable downtowns.&rdquo;<br />\r\n<br />\r\nThe U.S. decision to disburse the money widely drew criticism as well. Spreading it to 31 states means no corridor will get enough to fully fund the creation of high-speed rail service, Ron Utt, a senior research fellow at the Heritage Foundation in Washington, said in an interview.<br />\r\n<br />\r\nStrapped States<br />\r\n<br />\r\n&ldquo;You really don&rsquo;t have enough money to really do anything other than lots of surveys, maybe some land acquisition, engineering studies and all that sort of stuff,&rdquo; Utt said. &ldquo;Unless more federal money is forthcoming in the future, these places are still going to struggle for resources because the states are in even worse condition than the federal government.&rdquo;<br />\r\n<br />\r\nCompanies that manufacture train and rail components may benefit from the spending. General Electric Co. and Siemens AG are among 32 manufacturers that pledged last year, at the behest of the Transportation Department, to establish U.S. rail- manufacturing operations or expand their domestic workforce if they get some of the rail funding. States will allocate after they receive it.<br />\r\n<br />\r\nCentral Japan Railway, which owns Japan&rsquo;s largest maker of bullet trains, and Hitachi Ltd. are among Japanese companies that have begun targeting export sales, including to the U.S.<br />\r\n<br />\r\nGE, the world&rsquo;s biggest maker of freight locomotives, is developing engines for passenger trains that could operate at 124 mph, said Stephan Koller, a spokesman for the Fairfield, Connecticut-based company&rsquo;s transportation unit. GE announced a partnership with China&rsquo;s Ministry of Railways in November to manufacture equipment for high-speed rail projects in the U.S.<br />\r\n<br />\r\n&ldquo;We are going to support any state that wants to do high- speed rail,&rdquo; Koller said today in an interview.</p>', 'true', '1264729579', 'true', 'California and Florida are the biggest winners among 31 states sharing $8 billion in rail grants from the U.S. economic stimulus package.<BR>', '280', 0, 'goc_1264729579.jpg', '');
INSERT INTO `hdc_product2` VALUES (405, 'U.S solar developer forms Vietnam -based subsidiary', '276', 'thumb_1264729775.jpg', '', 'true', '<p>Cenergy Power, a leading commercial solar developer in California, today announced the legal formation of a Vietnam-based subsidiary focusing on utility-scale solar power development and project-level human capital build-up in Southeast Asia. <br />\r\n<br />\r\nCenergy Power expects its California project revenues to grow by an order of magnitude in 2010 and is now focused on the long-term potential of solar in emerging markets around the world. The company is currently negotiating several megawatt-sized pilot projects with local utilities and stakeholders in Vietnam, and will employ up to 100 solar installers and field service engineers over the next twelve months to construct and service projects within and outside of Southeast Asia. <br />\r\n<br />\r\nCenergy Power has tapped Ascenx Technologies, a seasoned Vietnam-based engineering services provider for the semiconductor and upstream solar industries, to assist in the recruitment, training and development of Cenergy''s local human capital requirements.<br />\r\n<br />\r\n&quot;Our market analysis tells us that the fluid solar market will expand very quickly beyond China into nearby Southeast Asia countries, where power demand severely outstrips supply and grid parity for Cenergy Power can be reached within one year,&quot; says Nader Yarpezeshkan, Director of Business Development for Cenergy Power. &quot;We have benefited tremendously from being ahead of the curve in certain key market segments in California and we believe a similar methodical approach to the Southeast Asia market could yield even bigger results over the next few years.&quot;</p>', 'true', '1264731492', 'true', 'Cenergy Power, a commercial solar developer in California, today announced the legal formation of a Vietnam-based subsidiary. <BR>', '291', 0, '1264729775Solar-company-enlisted-by-California-almond-huller-for-PV-project_295x22020100128090611.jpg', '');
INSERT INTO `hdc_product2` VALUES (406, 'Homeritz to set up new factory in Vietnam', '276', 'thumb_1264729848.jpg', '', 'true', '<p>Homeritz Corporation Bhd, a Johor-based home furniture maker, is to spend RM9.12 million to set up factories in Vietnam and Muar, Johor, Malaysia, according to the Malaysian news agency Bernama.<br />\r\n<br />\r\nExecutive Director Tee Hwee Ing said RM3.4 million would be invested in its Vietnam plant including to buy new machinery and equipment.<br />\r\n<br />\r\n&quot;We are in the advanced stage of negotiations to lease two factory buildings in Binh Duong province. We hope to obtain regulatory approvals from the Vietnamese authorities by the second quarter of this year,&quot; she said.<br />\r\n<br />\r\nThe factories, expected to boost the company''s output capacity by 24,000 sofa sets a year, will be fully operational by the second half of this year, she said, adding that RM5.72 million would be used to build the Muar plant.<br />\r\n<br />\r\nThe plant would be funded from proceeds of its initial public offering (IPO). The group is expected to be listed on the Main Market of Bursa Malaysia by next month.<br />\r\n<br />\r\n&quot;The Muar plant is expected to be completed in two years. Once completed, it is expected to increase the group''s production capacity by another 15 per cent,&quot; she said at the company''s prospectus launching Wednesday.<br />\r\n<br />\r\nTee said the new plant would take over production of its current rented factory, also in Muar. Currently, the company owns three factories.<br />\r\n<br />\r\nIts IPO entails the public issue of nine million new ordinary shares and an offer-for-sale of 35.02 million vendor shares at 65 sen each IPO price.<br />\r\n<br />\r\nOf the nine million new shares, eight million would be offered to the public and the remaining one million would be allocated to eligible directors, employees and business associates, she said.<br />\r\n<br />\r\nOf the 35.02 million existing shares, 20 million units will be allocated to government-approved Bumiputera investors, 8.02 million shares will be placed out and the remaining seven million shares will be offered to the public.<br />\r\n<br />\r\nPrior to the listing, Homeritz will undertake a renounceable rights issue of 10.10 million shares. Cumulatively, it will raise RM7.87 million in gross proceeds.</p>', 'true', '1264729848', 'true', 'Home furniture maker Homeritz Corporation Bhd is to spend RM9.12 million to set up new factories in Vietnam and Malaysia. <BR>', '291', 0, 'goc_1264729848.jpg', '');
INSERT INTO `hdc_product2` VALUES (407, 'Frenzy with Tiger Translate 2010', '282', 'thumb_1264731579.jpg', '', 'true', '<p>A music show called Tiger Translate 2010 with a performance by the UK&rsquo;s Melodramas rock band and two Vietnamese rock bands, Unlimited and Microwave, will take place at the discotheque Apocalypse in Ho Chi Minh City on February 4.</p>\r\n<p>The event promises to bring audiences a fascinating experience of music and culture together with the frenzy and strength of rock.<br />\r\n<br />\r\nThe event aims to support Vietnamese talents to show off their personalities and to exchange with international friends. Tiger Translate is a Tiger Beer cross-cultural creative platform, highlighting Asia&rsquo;s bright creativeness and collaboration with Western visionaries through a series of events, exhibitions and publications.<br />\r\n<br />\r\nFounded in 2008, Melodramas is famous for its young, dynamic style and hilarious punk rock songs. The band includes Gregory on bass, Matthew and Robert on guitar and vocals and Samuel on drums.<br />\r\n<br />\r\nMicrowave is well-known to rock lovers with its nu-metal style and modern rock pieces while Unlimited conquers audiences with its power metal style.</p>', 'true', '1264731579', 'true', 'A music show with a performance by the UK’s Melodramas rock band and two Vietnamese rock bands will take place in HCMC on February 4.<BR>', '289', 0, '12647315798144704.jpg', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_shoppingcart`
-- 

CREATE TABLE `hdc_shoppingcart` (
  `id` int(5) NOT NULL auto_increment,
  `fullname` varchar(255) character set utf8 default NULL,
  `email` varchar(255) character set utf8 default NULL,
  `telephone` varchar(255) character set utf8 default NULL,
  `mobiphone` varchar(255) character set utf8 default NULL,
  `cmtnd` varchar(255) character set utf8 default NULL,
  `bank` varchar(255) character set utf8 default NULL,
  `detail` text character set utf8,
  `postdate` varchar(20) character set utf8 default NULL,
  `address` varchar(255) character set utf8 default NULL,
  `masp` varchar(255) character set utf8 default NULL,
  `status` enum('false','true') character set utf8 default 'false',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=45 ;

-- 
-- Dumping data for table `hdc_shoppingcart`
-- 

INSERT INTO `hdc_shoppingcart` VALUES (43, 'vuhuy', 'eeeeeeeeeeeeeeeeeee', 'eeeeeeeeeeeeeeeeeee', '', '', '', '', '1223516933', 'eeeeeeeeee', '283', 'true');
INSERT INTO `hdc_shoppingcart` VALUES (44, 'eeee', 'eeeeeeeeeeeeeeeeeee', 'eeeeeeeeeeeeeeeeeee', '', '', '', 'gggggggggggggggggj', '1223567207', 'eeeeeeeeee', '288', 'true');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_support`
-- 

CREATE TABLE `hdc_support` (
  `id` int(11) NOT NULL auto_increment,
  `nick` varchar(100) character set utf8 default NULL,
  `kind` int(5) default NULL,
  `stt` int(5) default NULL,
  `status` enum('false','true') character set utf8 default 'true',
  `fullname` varchar(255) character set utf8 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

-- 
-- Dumping data for table `hdc_support`
-- 

INSERT INTO `hdc_support` VALUES (17, 'huy_hdc', 2, 2, 'true', 'Sales');
INSERT INTO `hdc_support` VALUES (23, 'huy_hdc', 1, 1, 'true', 'Support');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_website`
-- 

CREATE TABLE `hdc_website` (
  `id` int(10) NOT NULL auto_increment,
  `title` varchar(200) collate utf8_unicode_ci default NULL,
  `website` varchar(200) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `hdc_website`
-- 

INSERT INTO `hdc_website` VALUES (1, 'Công ty HDC', 'hdc.vn');
INSERT INTO `hdc_website` VALUES (2, 'Báo dân trí', 'dantri.com.vn');
