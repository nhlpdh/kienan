-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Feb 26, 2010 at 08:45 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `mau3`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_admin`
-- 

CREATE TABLE `hdc_admin` (
  `id` int(5) NOT NULL auto_increment,
  `username` varchar(20) collate utf8_unicode_ci default NULL,
  `password` varchar(40) collate utf8_unicode_ci default NULL,
  `user_mod` int(5) default NULL,
  `fullname` varchar(255) character set utf8 default NULL,
  `status` enum('false','true') character set utf8 default 'true',
  `modn` varchar(2) character set utf8 default '0',
  `email` varchar(200) character set utf8 NOT NULL,
  `ma` varchar(200) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=26 ;

-- 
-- Dumping data for table `hdc_admin`
-- 

INSERT INTO `hdc_admin` VALUES (23, 'admin', 'c3284d0f94606de1fd2af172aba15bf3', NULL, 'admin', 'true', '1', 'huy_hdc@yahoo.com', NULL);
INSERT INTO `hdc_admin` VALUES (22, 'huyen', '87bf29a54cfcfefb8759e1d5d99457df', NULL, 'vuhuy', 'true', '1', 'hdc789@gmail.com', '2754032');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_ads`
-- 

CREATE TABLE `hdc_ads` (
  `id` int(11) NOT NULL auto_increment,
  `picture` varchar(200) character set utf8 default NULL,
  `link` varchar(200) character set utf8 default NULL,
  `stt` int(5) default NULL,
  `alignment` int(5) default NULL,
  `status` enum('false','true') character set utf8 default 'true',
  `postdate` varchar(255) character set utf8 default NULL,
  `title` varchar(200) character set utf8 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=195 ;

-- 
-- Dumping data for table `hdc_ads`
-- 

INSERT INTO `hdc_ads` VALUES (188, '1264360122_1252935987_tieudiem.jpg', 'http://www.hdc.vn', 1, 2, 'true', '1264360122', 'hdc.vn');
INSERT INTO `hdc_ads` VALUES (192, '1267230791_head_4.jpg', 'http://', 1, 3, 'true', '1267230791', 'GIỮA 1');
INSERT INTO `hdc_ads` VALUES (193, '1267230849_35.gif', 'http://', 1, 3, 'true', '1267230849', 'GIỮA 2');
INSERT INTO `hdc_ads` VALUES (187, '1264360075_83661250136810.jpg', 'http://www.nhadat360.net', 1, 1, 'true', '1264360075', 'nhadat360.net');
INSERT INTO `hdc_ads` VALUES (186, '1267229599_10-1-2009-2-03-11-PM-10317589.jpg', 'http://', 1, 4, 'true', '1267229599', 'banner');
INSERT INTO `hdc_ads` VALUES (194, '1267230862_header.jpg', 'http://', 1, 3, 'true', '1267230862', 'GIỮA 3');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_anh`
-- 

CREATE TABLE `hdc_anh` (
  `id` int(5) NOT NULL auto_increment,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `category` varchar(5) character set utf8 default NULL,
  `picture` varchar(200) collate utf8_unicode_ci default NULL,
  `status` enum('false','true') character set utf8 default 'true',
  `postdate` varchar(100) collate utf8_unicode_ci default NULL,
  `subCategory` varchar(5) character set utf8 default NULL,
  `solan` int(6) default '0',
  `picture2` varchar(200) character set utf8 default NULL,
  `tomtat` text character set utf8,
  `luachon` varchar(20) collate utf8_unicode_ci default NULL,
  `stt` int(10) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=568 ;

-- 
-- Dumping data for table `hdc_anh`
-- 

INSERT INTO `hdc_anh` VALUES (544, '05', '378', 'thumb_1264139146.jpg', 'true', '1264139146', '', NULL, 'goc_1264139146.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (543, '04', '378', 'thumb_1264139136.jpg', 'true', '1264139136', '', NULL, 'goc_1264139136.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (542, '03', '378', 'thumb_1264139125.jpg', 'true', '1264139125', '', NULL, 'goc_1264139125.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (541, '02', '378', 'thumb_1264139113.jpg', 'true', '1264139114', '', NULL, 'goc_1264139114.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (540, '01', '378', 'thumb_1264139103.jpg', 'true', '1264139103', '', NULL, 'goc_1264139103.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (539, '05', '377', 'thumb_1264139072.jpg', 'true', '1264139073', '', NULL, '12641390721255888567keu8.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (538, '04', '377', 'thumb_1264139061.jpg', 'true', '1264139061', '', NULL, '12641390611255888538keu5.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (537, '03', '377', 'thumb_1264139032.jpg', 'true', '1264139043', '', NULL, '12641390321255888525keu2.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (535, '01', '377', 'thumb_1264138991.jpg', 'true', '1264138991', '', NULL, '12641389911255888170keu3.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (536, '02', '377', 'thumb_1264139006.jpg', 'true', '1264139006', '', NULL, '12641390061255888511keu1.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (545, '01', '379', 'thumb_1264139228.jpg', 'true', '1264139228', '', NULL, '12641392281255888553keu7.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (546, '02', '379', 'thumb_1264139242.jpg', 'true', '1264139242', '', NULL, 'goc_1264139242.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (547, '03', '379', 'thumb_1264139253.jpg', 'true', '1264139254', '', NULL, 'goc_1264139254.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (548, '04', '379', 'thumb_1264139264.jpg', 'true', '1264139264', '', NULL, 'goc_1264139264.jpg', '', NULL, 1);
INSERT INTO `hdc_anh` VALUES (553, '02', '386', 'thumb_1264359000.jpg', 'true', '1264359000', '387', 0, 'goc_1264359000.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (552, '01', '386', 'thumb_1264358984.jpg', 'true', '1264358984', '387', 0, 'goc_1264358984.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (554, '03', '386', 'thumb_1264359017.jpg', 'true', '1264359017', '387', 0, 'goc_1264359017.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (555, '04', '386', 'thumb_1264359037.jpg', 'true', '1264359038', '387', 0, '1264359037ES1b.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (556, '05', '386', 'thumb_1264359056.jpg', 'true', '1264359056', '387', 0, 'goc_1264359056.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (557, '06', '386', 'thumb_1264359070.jpg', 'true', '1264359070', '387', 0, 'goc_1264359070.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (558, '07', '386', 'thumb_1264359090.jpg', 'true', '1264359090', '387', 0, 'goc_1264359090.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (559, '08', '386', 'thumb_1264359119.jpg', 'true', '1264359120', '387', 0, '1264359119H1.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (560, '01', '386', 'thumb_1264359341.jpg', 'true', '1264359341', '388', 0, 'goc_1264359341.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (561, '02', '386', 'thumb_1264359349.jpg', 'true', '1264359349', '388', 0, '1264359349080922180704-721-952.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (562, '03', '386', 'thumb_1264359357.jpg', 'true', '1264359357', '388', 0, '1264359356c0a4821976df69def7702fd86f26a807.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (563, '04', '386', 'thumb_1264359366.jpg', 'true', '1264359366', '388', 0, 'goc_1264359366.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (564, '05', '386', 'thumb_1264359377.jpg', 'true', '1264359377', '388', 0, '1264359377ici_xe may silver wing.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (565, '06', '386', 'thumb_1264359390.jpg', 'true', '1264359390', '388', 0, 'goc_1264359390.jpg', NULL, NULL, 1);
INSERT INTO `hdc_anh` VALUES (566, '07', '386', 'thumb_1264359400.jpg', 'true', '1264368414', '388', 0, '1264359400photo-28-05-08-03-28-05.jpg', NULL, NULL, 5);
INSERT INTO `hdc_anh` VALUES (567, '08', '386', 'thumb_1264359410.jpg', 'true', '1264367977', '388', 0, 'goc_1264359410.jpg', NULL, NULL, 2);

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_bodem`
-- 

CREATE TABLE `hdc_bodem` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(200) character set utf8 default NULL,
  `tong` int(5) default NULL,
  `status` enum('false','true') character set utf8 default 'true',
  `postdate` varchar(255) character set utf8 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=763 ;

-- 
-- Dumping data for table `hdc_bodem`
-- 

INSERT INTO `hdc_bodem` VALUES (345, '127.0.0.1', 23827, 'true', '1215118518');
INSERT INTO `hdc_bodem` VALUES (344, '127.0.0.1', 23827, 'true', '1215118517');
INSERT INTO `hdc_bodem` VALUES (343, '127.0.0.1', 23827, 'true', '1215118515');
INSERT INTO `hdc_bodem` VALUES (342, '127.0.0.1', 23827, 'true', '1215118514');
INSERT INTO `hdc_bodem` VALUES (341, '127.0.0.1', 23827, 'true', '1215118512');
INSERT INTO `hdc_bodem` VALUES (340, '127.0.0.1', 23827, 'true', '1215118510');
INSERT INTO `hdc_bodem` VALUES (339, '127.0.0.1', 23827, 'true', '1215723300');
INSERT INTO `hdc_bodem` VALUES (338, '127.0.0.1', 23827, 'true', '1215723284');
INSERT INTO `hdc_bodem` VALUES (337, '127.0.0.1', 23827, 'true', '1215723283');
INSERT INTO `hdc_bodem` VALUES (336, '127.0.0.1', 23827, 'true', '1215723282');
INSERT INTO `hdc_bodem` VALUES (335, '127.0.0.1', 23827, 'true', '1215723280');
INSERT INTO `hdc_bodem` VALUES (334, '127.0.0.1', 23827, 'true', '1215723271');
INSERT INTO `hdc_bodem` VALUES (333, '127.0.0.1', 23827, 'true', '1215032060');
INSERT INTO `hdc_bodem` VALUES (332, '127.0.0.1', 23827, 'true', '1215032059');
INSERT INTO `hdc_bodem` VALUES (331, '127.0.0.1', 23827, 'true', '1215032058');
INSERT INTO `hdc_bodem` VALUES (330, '127.0.0.1', 23827, 'true', '1215032057');
INSERT INTO `hdc_bodem` VALUES (329, '127.0.0.1', 23827, 'true', '1215032055');
INSERT INTO `hdc_bodem` VALUES (328, '127.0.0.1', 23827, 'true', '1215032047');
INSERT INTO `hdc_bodem` VALUES (327, '127.0.0.1', 23827, 'true', '1215032002');
INSERT INTO `hdc_bodem` VALUES (326, '127.0.0.1', 23827, 'true', '1215032000');
INSERT INTO `hdc_bodem` VALUES (325, '127.0.0.1', 23827, 'true', '1215031996');
INSERT INTO `hdc_bodem` VALUES (324, '127.0.0.1', 23827, 'true', '1214945589');
INSERT INTO `hdc_bodem` VALUES (323, '127.0.0.1', 23827, 'true', '1214945586');
INSERT INTO `hdc_bodem` VALUES (322, '127.0.0.1', 23827, 'true', '1214945573');
INSERT INTO `hdc_bodem` VALUES (321, '127.0.0.1', 23827, 'true', '1214945570');
INSERT INTO `hdc_bodem` VALUES (241, '127.0.0.1', 23827, 'true', '1206736031');
INSERT INTO `hdc_bodem` VALUES (376, '117.0.28.54', 23827, 'true', '1234164629');
INSERT INTO `hdc_bodem` VALUES (377, '117.0.28.54', 23827, 'true', '1234164973');
INSERT INTO `hdc_bodem` VALUES (378, '117.0.28.54', 23827, 'true', '1234165013');
INSERT INTO `hdc_bodem` VALUES (379, '117.0.232.16', 23827, 'true', '1234174067');
INSERT INTO `hdc_bodem` VALUES (743, NULL, 23827, 'true', NULL);
INSERT INTO `hdc_bodem` VALUES (744, '127.0.0.1', 23827, 'true', '1250469656');
INSERT INTO `hdc_bodem` VALUES (745, '127.0.0.1', 23827, 'true', '1250470480');
INSERT INTO `hdc_bodem` VALUES (746, '127.0.0.1', 23827, 'true', '1250471131');
INSERT INTO `hdc_bodem` VALUES (747, '127.0.0.1', 23827, 'true', '1250471743');
INSERT INTO `hdc_bodem` VALUES (748, '127.0.0.1', 23827, 'true', '1250472783');
INSERT INTO `hdc_bodem` VALUES (749, '127.0.0.1', 23827, 'true', '1250473388');
INSERT INTO `hdc_bodem` VALUES (750, '127.0.0.1', 23827, 'true', '1250473561');
INSERT INTO `hdc_bodem` VALUES (751, '127.0.0.1', 23827, 'true', '1250474040');
INSERT INTO `hdc_bodem` VALUES (752, '127.0.0.1', 23827, 'true', '1250474176');
INSERT INTO `hdc_bodem` VALUES (753, '127.0.0.1', 23827, 'true', '1250476943');
INSERT INTO `hdc_bodem` VALUES (754, '127.0.0.1', 23827, 'true', '1250486779');
INSERT INTO `hdc_bodem` VALUES (755, '127.0.0.1', 23827, 'true', '1250633098');
INSERT INTO `hdc_bodem` VALUES (756, '127.0.0.1', 23827, 'true', '1250634384');
INSERT INTO `hdc_bodem` VALUES (757, '127.0.0.1', 23827, 'true', '1250634989');
INSERT INTO `hdc_bodem` VALUES (758, '127.0.0.1', 23827, 'true', '1250635704');
INSERT INTO `hdc_bodem` VALUES (759, '127.0.0.1', 23827, 'true', '1250636317');
INSERT INTO `hdc_bodem` VALUES (760, '127.0.0.1', 23827, 'true', '1250636918');
INSERT INTO `hdc_bodem` VALUES (761, '127.0.0.1', 23827, 'true', '1250637542');
INSERT INTO `hdc_bodem` VALUES (762, '127.0.0.1', 23827, 'true', '1250638163');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_bottom`
-- 

CREATE TABLE `hdc_bottom` (
  `id` int(11) NOT NULL auto_increment,
  `full_intro` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

-- 
-- Dumping data for table `hdc_bottom`
-- 

INSERT INTO `hdc_bottom` VALUES (15, '								<br><div style="text-align: center;"><div style="text-align: left;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color: rgb(204, 0, 0);">&nbsp; <span style="font-weight: bold;">Công ty cổ phần</span></span><br style="color: rgb(204, 0, 0); font-weight: bold;"><span style="color: rgb(204, 0, 0); font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Địa chỉ: </span><br style="color: rgb(204, 0, 0); font-weight: bold;"><span style="color: rgb(204, 0, 0); font-weight: bold;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Điện thoại: </span><br style="color: rgb(255, 255, 255);"></div><br></div>');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_contact`
-- 

CREATE TABLE `hdc_contact` (
  `id` int(10) NOT NULL auto_increment,
  `fullname` varchar(255) character set utf8 default NULL,
  `address` varchar(255) character set utf8 default NULL,
  `telephone` varchar(255) character set utf8 default NULL,
  `email` varchar(200) character set utf8 default NULL,
  `title` varchar(255) character set utf8 default NULL,
  `content` text character set utf8,
  `postdate` varchar(50) character set utf8 default NULL,
  `status` enum('false','true') character set utf8 default 'false',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `hdc_contact`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_contact2`
-- 

CREATE TABLE `hdc_contact2` (
  `id` int(5) NOT NULL auto_increment,
  `full_intro` text collate utf8_unicode_ci,
  `email` varchar(200) character set utf8 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=74 ;

-- 
-- Dumping data for table `hdc_contact2`
-- 

INSERT INTO `hdc_contact2` VALUES (73, '<br>Mọi chi tiết xin quý khách vui lòng nhập vào form dưới đây:<br><br>', 'tdfhsdfh');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_download`
-- 

CREATE TABLE `hdc_download` (
  `id` int(5) NOT NULL auto_increment,
  `title` text character set utf8,
  `picture` varchar(255) character set utf8 default NULL,
  `short` text character set utf8,
  `full` text character set utf8,
  `postdate` varchar(20) character set utf8 default NULL,
  `status` enum('false','true') character set utf8 default 'true',
  `loai` varchar(100) character set utf8 default NULL,
  `link` text character set utf8,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=74 ;

-- 
-- Dumping data for table `hdc_download`
-- 

INSERT INTO `hdc_download` VALUES (73, 'ttt', '1264274625_1263497677_1257565633_untitled.JPG', '', '', '1264274625', 'true', '', 'http://');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_guide`
-- 

CREATE TABLE `hdc_guide` (
  `id` int(5) NOT NULL auto_increment,
  `full` text collate utf8_unicode_ci,
  `title` varchar(200) character set utf8 NOT NULL,
  `stt` varchar(200) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=82 ;

-- 
-- Dumping data for table `hdc_guide`
-- 

INSERT INTO `hdc_guide` VALUES (79, '	Đang cập nhật giới thiệu', 'Giới thiệu', '1');
INSERT INTO `hdc_guide` VALUES (80, 'Đang cập nhật tuyển dụng	', 'Tuyển dụng', '2');
INSERT INTO `hdc_guide` VALUES (81, 'Đang cập nhật hướng dẫn	', 'Hướng dẫn', '3');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_intro`
-- 

CREATE TABLE `hdc_intro` (
  `id` int(5) NOT NULL auto_increment,
  `full_intro` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=74 ;

-- 
-- Dumping data for table `hdc_intro`
-- 

INSERT INTO `hdc_intro` VALUES (1, '<span class="bodyContent" id="ctl14_ltrContent">\r\n<div>Trong khi loạt b&agrave;i về vấn nạn c&acirc;y sưa của ch&uacute;ng t&ocirc;i đang được thực hiện, s&aacute;ng sớm ng&agrave;y 17/9, c&acirc;y sưa mới hơn 7 năm tuổi trước cửa số nh&agrave; 114 Vũ Trọng Phụng (quận Thanh Xu&acirc;n, H&agrave; Nội) lại&nbsp;bị cưa trộm. C&acirc;y sưa kể tr&ecirc;n bị cắt rời l&agrave;m đ&ocirc;i rồi bị bỏ lại hiện trường, phần th&acirc;n tr&ecirc;n của c&acirc;y mắc kẹt v&agrave;o đ&aacute;m d&acirc;y c&aacute;p loằng ngoằng.</div>\r\n<div>&nbsp;</div>\r\n<div align="center"><span style="font-size: 10pt; font-family: Tahoma;"><img src="http://dantri.vcmedia.vn/Uploaded/2009/09/17/caysua_170909.jpg" alt="" /><br />\r\nHiện trường c&acirc;y sưa non bị chặt oan.</span></div>\r\n<div align="center">&nbsp;</div>\r\n<div>Theo một c&aacute;n bộ C&ocirc;ng ty C&ocirc;ng vi&ecirc;n c&acirc;y xanh H&agrave; Nội, c&acirc;y sưa n&agrave;y c&oacute; l&otilde;i sưa đỏ c&ograve;n rất nhỏ n&ecirc;n hầu như kh&ocirc;ng c&oacute; gi&aacute; trị về kinh tế, ch&iacute;nh v&igrave; thế n&ecirc;n bọn trộm mới bỏ c&acirc;y lại. Thời gian vừa qua, tr&ecirc;n địa b&agrave;n TP H&agrave; Nội từng ghi nhận nhiều c&acirc;y sưa non&nbsp;bị kẻ trộm d&ograve;m ng&oacute;, chặt oan.</div>\r\n<div>&nbsp;</div>\r\n<div>Đ&acirc;y l&agrave; vụ cưa trộm c&acirc;y sưa đỏ thứ 11 li&ecirc;n tiếp từ đầu th&aacute;ng 9 đến nay. Hiện trường vụ việc c&aacute;ch trụ sở c&ocirc;ng an quận Thanh Xu&acirc;n chưa đầy 400m.</div>\r\n<p>Như <span style="font-style: italic;">D&acirc;n tr&iacute;</span> đ&atilde; đưa tin, chiều 16/9, thiếu tướng Nguyễn Đức Nhanh, Gi&aacute;m đốc CATP đ&atilde; chỉ đạo lực lượng Cảnh s&aacute;t điều tra tội phạm về trật tự x&atilde; hội, lực lượng Cảnh s&aacute;t cơ động v&agrave; C&ocirc;ng an c&aacute;c quận huyện tr&ecirc;n địa b&agrave;n th&agrave;nh phố tập trung lập phương &aacute;n đấu tranh, ngăn chặn h&agrave;nh vi chặt ph&aacute; tr&aacute;i ph&eacute;p n&agrave;y.</p>\r\n<p>Gi&aacute;m đốc CATP y&ecirc;u cầu c&aacute;c đơn vị chuy&ecirc;n m&ocirc;n của CATP khẩn trương tập hợp chứng cứ, điều tra, l&agrave;m r&otilde; v&agrave; c&oacute; biện ph&aacute;p xử l&yacute; c&aacute;c đối tượng đ&atilde; g&acirc;y ra h&agrave;ng loạt vụ chặt ph&aacute; tr&aacute;i ph&eacute;p c&acirc;y sưa vừa qua tại H&agrave; Nội. Song song với việc điều tra, truy cứu tr&aacute;ch nhiệm những đối tượng chặt hạ c&acirc;y sưa, l&atilde;nh đạo CATP cũng y&ecirc;u cầu c&aacute;c đơn vị li&ecirc;n quan lập phương &aacute;n ngăn chặn ph&ograve;ng ngừa t&aacute;i diễn t&igrave;nh trạng n&agrave;y.</p>\r\n</span>');
INSERT INTO `hdc_intro` VALUES (2, 'Chào mừng bạn đến với website của chúng tôi, chúc bạn một ngày may mắn và hạnh phúc');
INSERT INTO `hdc_intro` VALUES (3, '<span class="bodyContent" id="ctl14_ltrContent">\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Khi &ocirc;m cậu con trai 5 th&aacute;ng tuổi trong v&ograve;ng tay của m&igrave;nh, chị B&ugrave;i Thị Thương kh&ocirc;ng c&ograve;n nước mắt để kh&oacute;c... Chị cứ h&ocirc;n h&iacute;t cậu con trai cho thoả nỗi nhớ sau những ng&agrave;y xa c&aacute;ch. Ch&aacute;u b&eacute; 5 th&aacute;ng tuổi kh&ocirc;i ng&ocirc;, trắng trẻo to&eacute;t miệng cười, đ&ocirc;i mắt tr&ograve;n ngơ ng&aacute;c khi thấy nhiều người lạ xung quanh&hellip;</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Vụ việc xảy ra v&agrave;o trưa 8/9, chị Thương trong t&acirc;m trạng hoảng loạn t&igrave;m đến Đội CSĐT tội phạm về TTXH, C&ocirc;ng an quận Long Bi&ecirc;n tr&igrave;nh b&aacute;o việc con trai chị bị một người phụ nữ mới quen biết bắt c&oacute;c...</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Chị Thương nghẹn ng&agrave;o kể lại: Ch&aacute;u Nhật Anh sinh ra kh&ocirc;ng nhận được sự thừa nhận của người đ&agrave;n &ocirc;ng chị y&ecirc;u. Th&aacute;ng 7/2009, chị mang con đến xin t&aacute; t&uacute;c tại một ng&ocirc;i ch&ugrave;a tr&ecirc;n địa b&agrave;n quận Long Bi&ecirc;n, quyết nu&ocirc;i con một m&igrave;nh. Trong thời gian ở ch&ugrave;a, chị quen một phụ nữ t&ecirc;n l&agrave; Nguyệt.</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Ng&agrave;y 26/8, ch&aacute;u Nhật Anh bị ốm nặng, chị Thương đưa con v&agrave;o Bệnh viện Đức Giang điều trị. L&uacute;c đ&oacute;, khoảng 10h ng&agrave;y 8/9, người phụ nữ t&ecirc;n Nguyệt dắt theo một ch&aacute;u b&eacute; t&igrave;m gặp chị Thương. L&uacute;c ấy, chị Thương pha cho con một b&igrave;nh sữa rồi nhờ Nguyệt bế hộ con để tranh thủ đi mua cơm. Khi chị Thương đi ra đến h&agrave;nh lang vẫn thấy Nguyệt ăn cơm, nhưng chị Thương quay v&agrave;o th&igrave; chẳng thấy Nguyệt đ&acirc;u.</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Linh t&iacute;nh m&aacute;ch bảo chị vội chạy ra căng tin ở bệnh viện, gọi điện thoại cho một phụ nữ t&ecirc;n l&agrave; Xoan, người ở c&ugrave;ng ch&ugrave;a để li&ecirc;n lạc với Nguyệt. Khoảng 15 ph&uacute;t sau, vẫn kh&ocirc;ng thấy Xoan gọi lại, chị hỏi th&igrave; được biết Nguyệt đ&atilde; tắt m&aacute;y kh&ocirc;ng li&ecirc;n lạc được. Cứ thế, Thương chạy khắp bệnh viện rồi mếu m&aacute;o t&igrave;m con.</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-weight: bold;">H&agrave;nh tr&igrave;nh lần manh mối ch&aacute;u b&eacute;<o:p></o:p></span></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Sau khi b&aacute;o c&aacute;o Ban chỉ huy C&ocirc;ng an quận, c&aacute;c mũi c&ocirc;ng t&aacute;c của Đội CSĐT tội phạm về TTXH, C&ocirc;ng an quận Long Bi&ecirc;n đ&atilde; toả đi khắp c&aacute;c địa b&agrave;n r&agrave; so&aacute;t, đồng thời li&ecirc;n hệ với C&ocirc;ng an ở một số địa phương c&oacute; tuyến bi&ecirc;n giới về đặc điểm nhận dạng của ch&aacute;u b&eacute; bị bắt c&oacute;c...</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Đầu mối của vụ &aacute;n h&eacute; mở, khi c&aacute;c anh c&oacute; t&agrave;i liệu, trước đ&oacute; v&agrave;i ng&agrave;y, Nguyệt n&oacute;i với một số người rằng chị ta về Hưng Y&ecirc;n chơi. Tối 14/9, họ c&oacute; nguồn tin tại x&atilde; Đại Đồng, huyện Văn L&acirc;m (Hưng Y&ecirc;n), c&oacute; chị Nguyễn Thị Oanh vừa mua được một ch&aacute;u b&eacute; trai chừng 5 th&aacute;ng tuổi. L&uacute;c n&agrave;y, c&aacute;c trinh s&aacute;t đ&atilde; t&igrave;m v&agrave;o căn nh&agrave; của chị Oanh v&agrave; đưa ch&aacute;u b&eacute; về trụ sở để l&agrave;m r&otilde;.</p>\r\n</span>');
INSERT INTO `hdc_intro` VALUES (4, '<object height="140" width="180">\r\n<param name="movie" value="http://www.youtube.com/v/8f1ijAM9kps&amp;hl=en&amp;fs=1&amp;" />\r\n<param name="allowFullScreen" value="true" />\r\n<param name="allowscriptaccess" value="always" /><embed height="140" width="180" src="http://www.youtube.com/v/8f1ijAM9kps&amp;hl=en&amp;fs=1&amp;" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true"></embed></object>');
INSERT INTO `hdc_intro` VALUES (5, '5');
INSERT INTO `hdc_intro` VALUES (6, '<p>6dfgj fg</p>\r\n<br />');
INSERT INTO `hdc_intro` VALUES (7, '<p>7dgj</p>\r\n<br />');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_member2`
-- 

CREATE TABLE `hdc_member2` (
  `id` int(10) NOT NULL auto_increment,
  `fullname` varchar(255) character set utf8 default NULL,
  `address` varchar(255) character set utf8 default NULL,
  `telephone` varchar(255) character set utf8 default NULL,
  `email` varchar(200) character set utf8 default NULL,
  `postdate` varchar(50) character set utf8 default NULL,
  `status` enum('false','true') character set utf8 default 'false',
  `username` varchar(255) character set utf8 default NULL,
  `password` varchar(255) collate utf8_unicode_ci default NULL,
  `website` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

-- 
-- Dumping data for table `hdc_member2`
-- 

INSERT INTO `hdc_member2` VALUES (18, 'vuhuy', 'mmm', 'mmm', 'mmm', '1222367241', 'true', 'mmm', 'c4efd5020cb49b9d3257ffa0fbccc0ae', 'mmm');
INSERT INTO `hdc_member2` VALUES (17, 'vuhuy', 'hhh', 'hhh', 'hhh', '1222367126', 'true', 'hhh', 'a3aca2964e72000eea4c56cb341002a4', 'hhh');
INSERT INTO `hdc_member2` VALUES (19, 'kkk', 'hhhhhhhhhhhhhhhhhhh', 'hhhhhhhhhhhhhhhhh', 'hhhhhhhhhhhhhhhhhhh', '1223511935', 'false', 'kkk', 'kkk', 'hhhhhhhhhhhhhhhhhhhhh');
INSERT INTO `hdc_member2` VALUES (20, 'aaaaaaaaaa', 'aaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaa', '1223512693', 'true', 'aaa', 'aaa', 'aaa');
INSERT INTO `hdc_member2` VALUES (21, 'eeee', 'eeeeeeeeee', 'eeeeeeeeeeeeeeeeeee', 'eeeeeeeeeeeeeeeeeee', '1223512810', 'true', 'eee', '670da91be64127c92faac35c8300e814', 'eee');
INSERT INTO `hdc_member2` VALUES (22, 'lll', 'lll', 'lll', 'lll', '1223517474', 'true', 'lll', 'bf083d4ab960620b645557217dd59a49', 'lll');
INSERT INTO `hdc_member2` VALUES (23, 'vuhuy', 'hksdjgs', 'hsklgsdg', 'huy_hdc@yahoo.com', '1223518061', 'true', 'huy', 'e77f82936e7e4577e2defed037208b7f', '1234');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_menu_anh`
-- 

CREATE TABLE `hdc_menu_anh` (
  `id` int(5) NOT NULL auto_increment,
  `category` varchar(100) collate utf8_unicode_ci NOT NULL default '',
  `status` enum('true','false') collate utf8_unicode_ci NOT NULL default 'true',
  `stt` int(5) NOT NULL default '0',
  `parent` int(5) default '0',
  `picture` varchar(200) collate utf8_unicode_ci NOT NULL,
  `picture2` varchar(200) character set utf8 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=390 ;

-- 
-- Dumping data for table `hdc_menu_anh`
-- 

INSERT INTO `hdc_menu_anh` VALUES (322, 'Gường bệnh nhân Inox', 'true', 3, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (323, 'Sản xuất tại JAPAN', 'true', 1, 290, '', '');
INSERT INTO `hdc_menu_anh` VALUES (324, 'Sản xuất tại USA', 'true', 2, 290, '', '');
INSERT INTO `hdc_menu_anh` VALUES (332, 'Ghế Inox', 'true', 2, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (333, 'Tủ thuốc,Tủ Inox', 'true', 4, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (334, 'Xe đẩy Inox,Bàn tiêm', 'true', 5, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (335, 'Thùng rác Y tế', 'true', 6, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (336, 'Bục lên xuống bàn đẻ', 'true', 7, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (337, 'Cọc truyền huyết thanh Inox', 'true', 8, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (342, 'Bồn rửa tay', 'true', 9, 320, '', '');
INSERT INTO `hdc_menu_anh` VALUES (379, 'Phong cảnh', 'true', 3, 0, 'thumb_1264138919.jpg', '12641389191255888553keu7.jpg');
INSERT INTO `hdc_menu_anh` VALUES (378, 'Động vật', 'true', 2, 0, 'thumb_1264138894.jpg', 'goc_1264138894.jpg');
INSERT INTO `hdc_menu_anh` VALUES (377, 'Hoa tuylip', 'true', 4, 0, 'thumb_1264138872.jpg', '12641388721255888170keu3.jpg');
INSERT INTO `hdc_menu_anh` VALUES (388, 'Xe máy', 'true', 2, 386, 'thumb_1264358938.jpg', '1264358938080831193537-895-450.jpg');
INSERT INTO `hdc_menu_anh` VALUES (387, 'Ô tô', 'true', 1, 386, 'thumb_1264358897.jpg', 'goc_1264358897.jpg');
INSERT INTO `hdc_menu_anh` VALUES (386, 'Ô tô - xe máy', 'true', 1, 0, 'thumb_1264358848.jpg', 'goc_1264358848.jpg');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_menu_product`
-- 

CREATE TABLE `hdc_menu_product` (
  `id` int(5) NOT NULL auto_increment,
  `category` varchar(100) collate utf8_unicode_ci NOT NULL default '',
  `status` enum('true','false') collate utf8_unicode_ci NOT NULL default 'true',
  `stt` int(5) NOT NULL default '1',
  `parent` int(5) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=375 ;

-- 
-- Dumping data for table `hdc_menu_product`
-- 

INSERT INTO `hdc_menu_product` VALUES (363, 'Áo đầm thời trang', 'true', 6, 0);
INSERT INTO `hdc_menu_product` VALUES (362, 'Thời trang thu đông', 'true', 5, 0);
INSERT INTO `hdc_menu_product` VALUES (361, 'Quần áo thể thao nữ', 'true', 4, 0);
INSERT INTO `hdc_menu_product` VALUES (360, 'Thời trang công sở', 'true', 3, 0);
INSERT INTO `hdc_menu_product` VALUES (359, 'Áo thun - Áo phông nữ', 'true', 2, 0);
INSERT INTO `hdc_menu_product` VALUES (358, 'Tơ tằm', 'true', 5, 353);
INSERT INTO `hdc_menu_product` VALUES (357, 'Chất liệu cotton', 'true', 4, 353);
INSERT INTO `hdc_menu_product` VALUES (356, 'Chất liệu thô', 'true', 3, 353);
INSERT INTO `hdc_menu_product` VALUES (355, 'Chất liệu Voan', 'true', 2, 353);
INSERT INTO `hdc_menu_product` VALUES (354, 'Kaki', 'true', 1, 353);
INSERT INTO `hdc_menu_product` VALUES (353, 'Áo sơ mi nữ', 'true', 1, 0);
INSERT INTO `hdc_menu_product` VALUES (364, 'Thời trang áo váy', 'true', 7, 0);
INSERT INTO `hdc_menu_product` VALUES (365, 'Đồ ngủ nữ', 'true', 8, 0);
INSERT INTO `hdc_menu_product` VALUES (366, 'Quần jean nữ', 'true', 9, 0);
INSERT INTO `hdc_menu_product` VALUES (367, 'Phụ kiện thời trang', 'true', 10, 0);
INSERT INTO `hdc_menu_product` VALUES (368, 'Thời trang nam', 'true', 9, 0);
INSERT INTO `hdc_menu_product` VALUES (369, 'Thun', 'true', 1, 359);
INSERT INTO `hdc_menu_product` VALUES (370, 'Cotton', 'true', 2, 359);
INSERT INTO `hdc_menu_product` VALUES (371, 'Thô', 'true', 3, 359);
INSERT INTO `hdc_menu_product` VALUES (372, 'Quần tây nữ', 'true', 1, 360);
INSERT INTO `hdc_menu_product` VALUES (373, 'Quần âu nữ', 'true', 2, 360);
INSERT INTO `hdc_menu_product` VALUES (374, 'Quần kaki nữ', 'true', 3, 360);

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_menu_product2`
-- 

CREATE TABLE `hdc_menu_product2` (
  `id` int(5) NOT NULL auto_increment,
  `category` varchar(100) collate utf8_unicode_ci NOT NULL default '',
  `status` enum('true','false') collate utf8_unicode_ci NOT NULL default 'true',
  `stt` int(5) NOT NULL default '1',
  `parent` int(5) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=285 ;

-- 
-- Dumping data for table `hdc_menu_product2`
-- 

INSERT INTO `hdc_menu_product2` VALUES (206, 'Tập đoàn Tài chính', 'true', 1, 182);
INSERT INTO `hdc_menu_product2` VALUES (269, 'Tin tức', 'true', 1, 0);
INSERT INTO `hdc_menu_product2` VALUES (276, 'Dịch vụ', 'true', 2, 0);
INSERT INTO `hdc_menu_product2` VALUES (279, 'Tin kinh tế', 'true', 1, 269);
INSERT INTO `hdc_menu_product2` VALUES (280, 'Tin thể thao', 'true', 2, 269);
INSERT INTO `hdc_menu_product2` VALUES (281, 'Bảo hành', 'true', 3, 0);
INSERT INTO `hdc_menu_product2` VALUES (282, 'Đối tác', 'true', 4, 0);
INSERT INTO `hdc_menu_product2` VALUES (283, 'Thư giãn', 'true', 8, 0);
INSERT INTO `hdc_menu_product2` VALUES (284, 'Tư vấn', 'true', 5, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_product`
-- 

CREATE TABLE `hdc_product` (
  `id` int(5) NOT NULL auto_increment,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `category` int(5) default NULL,
  `picture` varchar(200) collate utf8_unicode_ci default NULL,
  `price` varchar(255) character set utf8 default NULL,
  `special` varchar(20) character set utf8 default NULL,
  `full` longtext character set utf8,
  `status` enum('false','true') character set utf8 default 'true',
  `postdate` varchar(100) collate utf8_unicode_ci default NULL,
  `discount` varchar(20) character set utf8 default NULL,
  `tomtat` text collate utf8_unicode_ci,
  `subCategory` varchar(5) character set utf8 default NULL,
  `solan` int(6) default '1',
  `picture2` varchar(200) character set utf8 default NULL,
  `luachon` varchar(20) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=529 ;

-- 
-- Dumping data for table `hdc_product`
-- 

INSERT INTO `hdc_product` VALUES (523, 'Ao thun nu tinh', 359, 'thumb_1267209181.jpg', '135000', '', '', 'true', '1267209181', '', '', '369', 1, '1267209181large394_1.jpg', '');
INSERT INTO `hdc_product` VALUES (522, 'Ao thun nu tinh', 359, 'thumb_1267209150.jpg', '140000', '', '', 'true', '1267209150', '', '', '369', 2, '1267209149large396_1.jpg', '');
INSERT INTO `hdc_product` VALUES (521, 'Ao thun nu tinh', 359, 'thumb_1267209117.jpg', '170000', '', '', 'true', '1267209117', '', '', '369', 2, '1267209117large397_1.jpg', '');
INSERT INTO `hdc_product` VALUES (520, 'Áo sơ mi nữ dài tay', 353, 'thumb_1267209009.jpg', '160000', '', '', 'true', '1267209010', '', '', '355', 8, '1267209009large34_1.jpg', '');
INSERT INTO `hdc_product` VALUES (519, 'Áo sơ mi nữ tính', 353, 'thumb_1267208984.jpg', '290000', 'true', '', 'true', '1267208984', '', '<p>Kích cỡ: Vai 37, ngực 86,tay 55, d&agrave;i 57</p>', '355', 7, '1267208983large35_1.jpg', '');
INSERT INTO `hdc_product` VALUES (518, 'Áo sơ mi nữ', 353, 'thumb_1267208954.jpg', '290000', 'true', '', 'true', '1267208954', '', '<p>M&agrave;u: trắng, c&ocirc;̉ cao ,thắt nơ Ngực 88, vai 35-37, tay 59, &aacute;o 62</p>', '355', 6, '1267208954large37_1.jpg', '');
INSERT INTO `hdc_product` VALUES (517, 'Thời trang áo sơ mi kẻ', 353, 'thumb_1267208910.jpg', '290000', '', '', 'true', '1267208910', '', '', '355', 5, 'goc_1267208910.jpg', '');
INSERT INTO `hdc_product` VALUES (516, 'Áo sơ mi nữ', 353, 'thumb_1267208834.jpg', '235000', '', '', 'true', '1267208834', '', '', '354', 1, '1267208834large666_1.jpg', '');
INSERT INTO `hdc_product` VALUES (515, 'Áo sơ mi nữ thời trang', 353, 'thumb_1267208793.jpg', '235000', 'true', '', 'true', '1267208793', '', '', '354', 5, '1267208793large667_1.jpg', '');
INSERT INTO `hdc_product` VALUES (514, 'Áo sơ mi thời trang', 353, 'thumb_1267208678.jpg', '235000', '', '', 'true', '1267208678', '', '', '354', 5, '1267208678small668_1.jpg', '');
INSERT INTO `hdc_product` VALUES (513, 'Áo sơ mi nữ thời trang', 353, 'thumb_1267208157.jpg', '390000', 'true', '', 'true', '1267208237', '', '', '354', 7, '1267208157large669_1.jpg', '');
INSERT INTO `hdc_product` VALUES (524, 'Ao thun nu tinh', 359, 'thumb_1267209213.jpg', '135000', 'true', '', 'true', '1267209214', '', '', '369', 1, '1267209213large391_1.jpg', '');
INSERT INTO `hdc_product` VALUES (525, 'Ao thun nu tinh', 359, 'thumb_1267209247.jpg', '180000', 'true', '', 'true', '1267209247', '', '', '369', 2, '1267209247large381_1.jpg', '');
INSERT INTO `hdc_product` VALUES (526, 'Ao thun nu tinh', 359, 'thumb_1267209432.jpg', '150000', 'true', '', 'true', '1267209432', '', '', '369', 2, '1267209432large366_1.jpg', '');
INSERT INTO `hdc_product` VALUES (527, 'Ao thun nu tinh', 359, 'thumb_1267209457.jpg', '140000', 'true', '', 'true', '1267209457', '', '', '369', 1, '1267209457large361_1.jpg', '');
INSERT INTO `hdc_product` VALUES (528, 'Ao thun nu tinh', 359, 'thumb_1267209490.jpg', '150000', 'true', '', 'true', '1267209491', '', '', '369', 12, '1267209490large374_1.jpg', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_product2`
-- 

CREATE TABLE `hdc_product2` (
  `id` int(5) NOT NULL auto_increment,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `category` varchar(5) character set utf8 default NULL,
  `picture` varchar(200) collate utf8_unicode_ci default NULL,
  `price` varchar(255) character set utf8 default NULL,
  `special` varchar(20) character set utf8 default NULL,
  `full` longtext collate utf8_unicode_ci,
  `status` enum('false','true') character set utf8 default 'true',
  `postdate` varchar(100) collate utf8_unicode_ci default NULL,
  `discount` varchar(20) character set utf8 default NULL,
  `tomtat` text collate utf8_unicode_ci,
  `subCategory` varchar(5) character set utf8 default NULL,
  `solan` int(6) default '0',
  `picture2` varchar(200) character set utf8 default NULL,
  `luachon` varchar(20) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=392 ;

-- 
-- Dumping data for table `hdc_product2`
-- 

INSERT INTO `hdc_product2` VALUES (386, 'Ngân hàng Mỹ khổ vì… thừa tiền', '269', 'thumb_1264357357.jpg', '', '', '<p><span class="bodyContent" id="ctl14_ltrContent">\r\n<div>&ldquo;Thừa vốn&rdquo; nghe qua c&oacute; vẻ tốt, nhất l&agrave; khi chỉ mới khoảng một năm trước ch&iacute;nh quyền li&ecirc;n bang c&ograve;n đang chạy đua để cứu hệ thống t&agrave;i ch&iacute;nh Mỹ khỏi sụp đổ. Tuy vậy, đ&aacute;ng bất ngờ l&agrave; c&oacute; qu&aacute; nhiều tiền cũng phiền phức y như chẳng c&oacute; g&igrave; vậy.</div>\r\n<p>&Aacute;p lực l&ecirc;n &ocirc;ng Dimon v&agrave; c&aacute;c CEO ng&acirc;n h&agrave;ng kh&aacute;c d&acirc;ng cao từ nhiều hướng: cổ đ&ocirc;ng muốn tăng cổ tức; doanh nghiệp nhỏ n&oacute;i ng&acirc;n h&agrave;ng n&ecirc;n cho vay nhiều hơn để phục hồi kinh tế; v&agrave; ch&iacute;nh quyền th&igrave; muốn đ&aacute;nh thuế c&aacute;c ng&acirc;n h&agrave;ng lớn để b&ugrave; đắp cho khoản thua lỗ của chương tr&igrave;nh cứu trợ dự kiến l&ecirc;n tới 117 tỷ USD.</p>\r\n<p>Trong số đ&oacute;, đ&ograve;i hỏi tăng cổ tức của cổ đ&ocirc;ng c&oacute; nhiều khả năng th&agrave;nh c&ocirc;ng nhất. JPMorgan Chase, vốn được coi l&agrave; quản l&yacute; tốt nhất trong số c&aacute;c ng&acirc;n h&agrave;ng lớn, c&oacute; lẽ sẽ l&agrave; ng&acirc;n h&agrave;ng đầu ti&ecirc;n tăng cổ tức.</p>\r\n<p>Matthew D. McCormick, nh&agrave; quản l&yacute; danh mục v&agrave; ph&acirc;n t&iacute;ch ng&acirc;n h&agrave;ng tại Bahl &amp; Gaynor Investment Counsel n&oacute;i: &ldquo;Ng&acirc;n h&agrave;ng n&agrave;o tăng cổ tức đầu ti&ecirc;n sẽ g&acirc;y ấn tượng với to&agrave;n bộ giới đầu tư&rdquo;.</p>\r\n<p>C&oacute; nhiều l&yacute; do để trả tiền cho cổ đ&ocirc;ng. Lợi suất trung b&igrave;nh từ cổ tức c&aacute;c ng&acirc;n h&agrave;ng lớn, tức l&agrave; cổ tức chia cho gi&aacute; cổ phiếu, đang ở mức thấp nhất kể từ năm 1997. C&aacute;c cơ quan điều tiết li&ecirc;n bang hiểu rằng ng&acirc;n h&agrave;ng muốn thưởng cho cổ đ&ocirc;ng để họ sẵn s&agrave;ng mua số cổ phiếu ph&aacute;t h&agrave;nh th&ecirc;m trong tương lai qua đ&oacute; củng cố cho số vốn của ng&acirc;n h&agrave;ng.</p>\r\n<p>JPMorgan Chase đi đầu sẽ tạo sức &eacute;p tăng cổ tức l&ecirc;n c&aacute;c ng&acirc;n h&agrave;ng kh&aacute;c, d&ugrave; t&igrave;nh h&igrave;nh t&agrave;i ch&iacute;nh của họ kh&ocirc;ng vững chắc bằng. D&ugrave; U.S. Bancorp v&agrave; BB&amp;T c&oacute; thể tăng cổ tức trong năm nay nhưng Citigroup v&agrave; Bank of America kh&ocirc;ng thể l&agrave;m vậy ch&iacute; &iacute;t đến năm 2011.</p>\r\n<p>Thừa vốn chưa chắc đ&atilde; l&agrave; khỏe mạnh. V&iacute; dụ như vốn của Citi chiếm 11,7% tổng t&agrave;i sản, cao hơn con số 11,1% của JPMorgan Chase v&agrave; vượt xa y&ecirc;u cầu tối thiểu 6% nhưng kh&ocirc;ng ai lại cho rằng Citi đang ở trong t&igrave;nh trạng tốt. Ng&acirc;n h&agrave;ng n&agrave;y th&ocirc;ng b&aacute;o khoản lỗ 7,6 tỷ USD trong qu&yacute; IV v&agrave; tỷ lệ vỡ nợ tr&ecirc;n danh mục cho vay tiếp tục cao.</p>\r\n<p>Trước khi JPMorgan hay bất kỳ ng&acirc;n h&agrave;ng n&agrave;o tăng cổ tức cũng phải được sự th&ocirc;ng qua của cơ quan gi&aacute;m s&aacute;t. Bản quy tắc của FED viết c&aacute;c cơ quan điều tiết phải c&acirc;n nhắc đến &ldquo;lợi nhuận hiện tại v&agrave; tương lai&rdquo; khi thẩm tra y&ecirc;u cầu n&agrave;y.</p>\r\n<p>Một số nh&agrave; kinh tế cho rằng kể cả c&aacute;c định chế h&ugrave;ng mạnh nhất cũng n&ecirc;n giữ tiền mặt v&igrave; khi gi&aacute; t&agrave;i sản giảm mạnh c&oacute; thể khiến họ mất thanh khoản v&agrave; cần đến g&oacute;i cứu trợ từ người nộp thuế.</p>\r\n<p>&ldquo;Ch&uacute;ng ta kh&ocirc;ng muốn c&aacute;c ng&acirc;n h&agrave;ng lớn, d&ugrave; cho c&oacute; tr&aacute;ch nhiệm hay kh&ocirc;ng, đ&aacute;nh bạc với tiền của người nộp thuế,&rdquo; Laurence J. Kotlikoff, nh&agrave; kinh tế tại ĐH Boston n&oacute;i.</p>\r\n<p>Một l&yacute; do để lo ngại l&agrave;: Ng&acirc;n h&agrave;ng c&oacute; thể vẫn kẹt trong thua lỗ v&igrave; danh mục cho vay bất động sản khổng lồ, Gi&aacute;m đốc C&ocirc;ng ty tư vấn t&agrave;i ch&iacute;nh Navigant Capital Advisors, &ocirc;ng Edward Casas n&oacute;i.</p>\r\n<p>Một dấu hiệu cho thấy c&aacute;c tập đo&agrave;n chưa ho&agrave;n to&agrave;n nhận ra thua lỗ của m&igrave;nh l&agrave; họ vẫn miễn cưỡng b&aacute;n t&agrave;i sản với c&aacute;i gi&aacute; hiện nay. &Ocirc;ng n&oacute;i c&aacute;c giao dịch cỡ nhỏ v&agrave; vừa &ldquo;về cơ bản bị đ&oacute;ng băng&rdquo; v&igrave; ng&acirc;n h&agrave;ng giữ gi&aacute; ch&agrave;o qu&aacute; cao.</p>\r\n<p>&ldquo;Tấm đệm&rdquo; tiền mặt n&ecirc;u bật một nghịch l&yacute; nữa: ng&acirc;n h&agrave;ng c&oacute; n&ecirc;n tăng cường cho vay hay kiểm so&aacute;t chặt khoản vay hơn để hạn chế rủi ro vỡ nợ? Gi&aacute; trị c&aacute;c khoản vay giảm từ 7.300 tỷ USD v&agrave;o th&aacute;ng 10/2008 xuống dưới 6.700 tỷ USD v&agrave;o đầu th&aacute;ng 1/2010.</p>\r\n<p>L&yacute; do ch&iacute;nh khiến t&iacute;n dụng suy giảm l&agrave; cuộc suy tho&aacute;i đ&atilde; biến những người đi vay tiềm năng th&agrave;nh những địa chỉ qu&aacute; rủi ro v&agrave; dập tắt nhu cầu t&iacute;n dụng của số kh&aacute;c. &ldquo;N&oacute; kh&ocirc;ng c&oacute; lợi với một m&ocirc;i trường kinh doanh th&acirc;n thiện với nh&agrave;&nbsp; đầu tư&rdquo; - Peter Sorrentino, người đang quản l&yacute; 13,8 tỷ USD tại Huntington Asset Advisors n&oacute;i.</p>\r\n<p>Một quan chức cao cấp của ch&iacute;nh quyền Obama n&oacute;i Nh&agrave; Trắng hy vọng ng&acirc;n h&agrave;ng sẽ lấy số tiền n&agrave;y từ quỹ lương thưởng nhưng điều n&agrave;y kh&ocirc;ng bắt buộc. N&oacute;i ngắn gọn l&agrave; kh&ocirc;ng &iacute;t người nhắm tới số &ldquo;vốn thừa&rdquo; của ng&acirc;n h&agrave;ng. Nhưng cho tới nay, c&oacute; vẻ như cổ đ&ocirc;ng sẽ l&agrave; người nhanh tay nhất.</p>\r\n</span></p>', 'true', '1264357357', '', '(Dân trí) - Trong một buổi nói chuyện với các nhà phân tích vào tháng 1, CEO Jamie Dimon của JPMorgan Chase nói từ giữa đến cuối năm 2010, nhiều ngân hàng sẽ rơi vào bi kịch “thừa vốn”.<BR>', '279', 0, '1264357357USDmoi24110.jpg', NULL);
INSERT INTO `hdc_product2` VALUES (387, 'Tăng lương tối thiểu: Người lao động và DN cùng kêu khổ', '269', 'thumb_1264357554.jpg', '', 'true', '<p><span class="bodyContent" id="ctl14_ltrContent">\r\n<p>Tiền lương tối thiểu chung hiện tại đang được quy định l&agrave; 650.000 đồng/th&aacute;ng cho bản th&acirc;n người lao động v&agrave; một người ăn theo. Mức lương tối thiểu chung được d&ugrave;ng để l&agrave;m căn cứ t&iacute;nh lương tối thiểu của bốn v&ugrave;ng kh&aacute;c nhau tr&ecirc;n cả nước.</p>\r\n<p>Trong lương tối thiểu v&ugrave;ng lại được chia ra l&agrave;m hai loại: lương tối thiểu v&ugrave;ng cho doanh nghiệp FDI v&agrave; doanh nghiệp trong nước (bao gồm doanh nghiệp nh&agrave; nước v&agrave; tư nh&acirc;n). Lương tối thiểu chung sẽ được tăng l&ecirc;n 730.000 đồng/th&aacute;ng v&agrave;o ng&agrave;y 1/5 tới.</p>\r\n<p>Tuy nhi&ecirc;n, theo &ocirc;ng Ho&agrave;ng Minh H&agrave;o, ph&oacute; vụ trưởng vụ Lao động - tiền lương, mức lương tối thiểu chung hiện nay qu&aacute; thấp, kh&ocirc;ng đảm bảo đủ mức sống tối thiểu cho người lao động. So s&aacute;nh với chuẩn ngh&egrave;o được ban h&agrave;nh từ năm 2005 th&igrave; mức lương tối thiểu n&agrave;y đang khiến người lao động sống cận ngh&egrave;o.</p>\r\n<p>&ldquo;Theo chuẩn ngh&egrave;o cho hai người được ban h&agrave;nh th&igrave; ở đ&ocirc; thị l&agrave; 520.000 đồng/th&aacute;ng v&agrave; ở n&ocirc;ng th&ocirc;n l&agrave; 400.000 người/th&aacute;ng. Như vậy chưa t&iacute;nh trượt gi&aacute; từ năm 2005 tới nay th&igrave; lương tối thiểu đang cận ngh&egrave;o&rdquo;, &ocirc;ng H&agrave;o n&oacute;i.</p>\r\n<p>Nếu t&iacute;nh theo chuẩn ngh&egrave;o quốc tế đối với c&aacute;c nước đang ph&aacute;t triển l&agrave; 1 USD/ng&agrave;y tương đương với 30 USD/th&aacute;ng v&agrave; 60 USD/th&aacute;ng cho hai người th&igrave; mức lương tối thiểu chung phải tương đương với khoảng 1,08 triệu đồng/th&aacute;ng.</p>\r\n<p>&ldquo;Trong khi đ&oacute; theo kinh nghiệm của c&aacute;c nước tr&ecirc;n thế giới th&igrave; lương tối thiểu chỉ c&oacute; thể thấp hơn mức lương trung b&igrave;nh đủ sống khoảng 25 - 30%, nhưng ở nước ta thấp hơn l&agrave; 40%&rdquo;, &ocirc;ng H&agrave;o cho biết.</p>\r\n<p>Lương tối thiểu thấp, kh&ocirc;ng được điều chỉnh kịp thời v&agrave; linh hoạt xuất ph&aacute;t từ sự phụ thuộc v&agrave;o ng&acirc;n s&aacute;ch nh&agrave; nước. Mỗi khi x&aacute;c định mức lương tối thiểu, c&aacute;c nh&agrave; l&agrave;m ch&iacute;nh s&aacute;ch thường căn cứ v&agrave;o khả năng chi trả của ng&acirc;n s&aacute;ch đối với lao động khu vực nh&agrave; nước, hơn l&agrave; nh&igrave;n v&agrave;o thực tế đời sống người lao động.</p>\r\n<p><span style="font-weight: bold">Doanh nghiệp: tăng chi ph&iacute;</span></p>\r\n<p>Trong khi người lao động kh&ocirc;ng thể tồn tại được với mức lương tối thiểu thấp th&igrave; những đợt tăng lương tối thiểu li&ecirc;n tiếp trong nhiều năm trở lại đ&acirc;y đ&atilde; khiến c&aacute;c doanh nghiệp k&ecirc;u v&igrave; chi ph&iacute; đầu v&agrave;o tăng.</p>\r\n<p>Theo bộ Lao động - thương binh v&agrave; x&atilde; hội, với việc tăng lương tối thiểu từ ng&agrave;y 1/1 vừa qua, mức lương b&igrave;nh qu&acirc;n chung tr&ecirc;n thị trường sẽ tăng khoảng 10%. Điều n&agrave;y c&oacute; t&aacute;c động đến hoạt động sản xuất kinh doanh của doanh nghiệp.</p>\r\n<p>Cụ thể, dự kiến tổng quỹ lương, quỹ bảo hiểm x&atilde; hội, bảo hiểm y tế, bảo hiểm thất nghiệp của doanh nghiệp sẽ tăng th&ecirc;m khoảng 4,6%, chi ph&iacute; của doanh nghiệp sẽ tăng th&ecirc;m khoảng 0,33% so với khi chưa tăng lương. Lợi nhuận của doanh nghiệp sẽ giảm khoảng 5% so với khi chưa tăng lương.</p>\r\n<p>Mức tăng tổng c&aacute;c quỹ lương, bảo hiểm x&atilde; hội, y tế, thất nghiệp ở c&aacute;c doanh nghiệp d&acirc;n doanh l&agrave; cao nhất, tương đương với 5,8% trong khi ở doanh nghiệp c&oacute; vốn đầu tư nước ngo&agrave;i l&agrave; 4,9% v&agrave; doanh nghiệp nh&agrave; nước l&agrave; 3,2%.</p>\r\n<p>C&aacute;c doanh nghiệp sử dụng nhiều lao động l&agrave; dệt may, da gi&agrave;y c&oacute; mức tăng khoảng 5,3%, chi ph&iacute; tăng th&ecirc;m 0,99% v&agrave; lợi nhuận dự kiến giảm 20,8% so với khi chưa tăng lương tối thiểu.</p>\r\n<p>&Ocirc;ng H&agrave;o thừa nhận việc tăng lương tối thiểu c&oacute; t&aacute;c động tới hoạt động sản xuất kinh doanh của doanh nghiệp. Trong bối cảnh doanh nghiệp kh&ocirc;ng tổ chức lại lao động cho hợp l&yacute; hơn hoặc t&igrave;m c&aacute;ch tăng năng suất lao động th&igrave; việc lương tối thiểu tăng li&ecirc;n tiếp sẽ t&aacute;c động kh&ocirc;ng tốt tới chi ph&iacute; đầu v&agrave;o v&agrave; lợi nhuận của doanh nghiệp.</p>\r\n</span></p>', 'true', '1264357554', '', 'Lương tối thiểu vừa được tăng từ ngày 1/1 vừa qua đối với lao động làm việc trong các doanh nghiệp. Tuy nhiên, mức tăng này không làm hài lòng cả người lao động và chủ sử dụng.<BR>', '279', 0, '1264357554Layluong23110.jpg', NULL);
INSERT INTO `hdc_product2` VALUES (388, 'Gần 30.000 tỷ đồng xây đường bộ ven biển', '269', 'thumb_1264357634.jpg', '', 'true', '<p><span class="bodyContent" id="ctl14_ltrContent">\r\n<div>Tuyến đường n&agrave;y bắt đầu tại cảng N&uacute;i Đỏ, Mũi Ngọc (x&atilde; B&igrave;nh Ngọc, TP. M&oacute;ng C&aacute;i, tỉnh Quảng Ninh) tới cửa khẩu H&agrave; Ti&ecirc;n (thị x&atilde; H&agrave; Ti&ecirc;n, tỉnh Ki&ecirc;n Giang).</div>\r\n<div>&nbsp;</div>\r\n<div>Việc đầu tư x&acirc;y dựng tuyến đường bộ ven biển được chia th&agrave;nh 2 giai đoạn. Theo đ&oacute;, giai đoạn 1 bắt đầu từ nay đến năm 2020, sẽ x&acirc;y mới, n&acirc;ng cấp&nbsp;khoảng 892 km đường ven biển với số vốn dự kiến tr&ecirc;n 16.000&nbsp;tỷ đồng. Giai đoạn 2 sẽ ho&agrave;n th&agrave;nh tiếp 1.058 km đường với số vốn&nbsp;đầu tư&nbsp;tr&ecirc;n 13.000 tỷ đồng.</div>\r\n<div>&nbsp;</div>\r\n<div>Đ&acirc;y l&agrave; tuyến đường bộ đi s&aacute;t biển nhằm khai th&aacute;c, sử dụng c&oacute; hiệu quả t&agrave;i nguy&ecirc;n biển v&agrave; v&ugrave;ng ven biển, phục vụ ph&aacute;t triển kinh tế - x&atilde; hội của c&aacute;c địa phương c&oacute; biển, tăng cường củng cố quốc ph&ograve;ng, an ninh nhằm bảo vệ vững chắc chủ quyền của đất nước.</div>\r\n<div>&nbsp;</div>\r\n<div>C&ugrave;ng đ&oacute; tuyến đường bộ n&agrave;y c&oacute; thể kết hợp với hệ thống đ&ecirc; biển v&agrave; hệ thống đường ph&ograve;ng thủ ven biển nhằm tạo thuận lợi trong xử l&yacute; c&aacute;c t&igrave;nh huống ứng ph&oacute; với thi&ecirc;n tai v&agrave; tăng cường củng cố quốc ph&ograve;ng, an ninh khu vực.</div>\r\n</span></p>', 'true', '1264357634', '', '(Dân trí) - Thủ tướng Chính phủ vừa phê duyệt Quy hoạch chi tiết đường bộ ven biển Việt Nam có chiều dài 3.041 km với kinh phí xây dựng gần 30.000 tỷ đồng.', '279', 0, '1264357634Venbien22110.jpg', NULL);
INSERT INTO `hdc_product2` VALUES (389, 'Real Madrid - Malaga: Chiến thắng hay là chết', '269', 'thumb_1264357704.jpg', '', 'true', '<p><span id="ctl14_ltrContent" class="bodyContent">\r\n<div style="margin: 0in 0in 0pt;" class="MsoNormal">Chưa khi n&agrave;o, c&aacute;c madridista lại ho&agrave;i nghi v&agrave; lo lắng về đội b&oacute;ng th&acirc;n y&ecirc;u của m&igrave;nh đến vậy. H&agrave;ng loạt t&acirc;n binh tổng trị gi&aacute; gần 300 triệu euro như Kaka, Ronaldo, Benzema hay Alonso gần như trở n&ecirc;n v&ocirc; hiệu trước h&agrave;ng thủ chắc chắn của <st1:city w:st="on"><st1:place w:st="on">Bilbao</st1:place></st1:city>. Kaka mờ nhạt, Ronaldo đi b&oacute;ng vẫn phức tạp, lắt nhắt nhưng thiếu hiệu quả.</div>\r\n<div style="margin: 0in 0in 0pt;" class="MsoNormal">&nbsp;&nbsp;</div>\r\n<div align="center" style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-size: 10pt; font-family: Tahoma;"><br />\r\n</span></div>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<div style="margin: 0in 0in 0pt;" class="MsoNormal">\r\n<table width="196" cellspacing="0" cellpadding="0" border="1" align="right" style="border: 1pt outset rgb(0, 90, 135); background: whitesmoke none repeat scroll 0% 0%; -moz-background-clip: border; -moz-background-origin: padding; -moz-background-inline-policy: continuous; width: 147.25pt;" class="MsoNormalTable">\r\n    <tbody>\r\n        <tr>\r\n            <td width="196" style="border: 1pt inset rgb(0, 90, 135); padding: 2.25pt; background: rgb(0, 90, 135) none repeat scroll 0% 0%; -moz-background-clip: border; -moz-background-origin: padding; -moz-background-inline-policy: continuous; width: 147.25pt;">\r\n            <p align="center" style="margin: 0in 0in 0pt; text-align: center;" class="msonospacing111111111111111111111"><span style="font-weight: bold; font-size: 10pt; color: white; font-family: Verdana;">V&ograve;ng&nbsp;19&nbsp;La Liga</span><span style="font-size: 10pt; font-family: Verdana;"><o:p></o:p></span></p>\r\n            </td>\r\n        </tr>\r\n        <tr style="height: 129.95pt;">\r\n            <td width="196" style="border: 1pt inset rgb(0, 90, 135); padding: 2.25pt; background: transparent none repeat scroll 0% 0%; -moz-background-clip: border; -moz-background-origin: padding; -moz-background-inline-policy: continuous; width: 147.25pt; height: 129.95pt;">\r\n            <p style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-weight: bold;"><span style="font-size: 10pt; color: black; font-style: italic; font-family: Verdana;">Chủ nhật, 24/1<o:p></o:p></span></span></p>\r\n            <p style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-size: 10pt; color: black; font-family: Verdana;">Sevilla <span style="font-weight: bold;">1<span style="font-weight: bold;">-0</span></span> <st1:place w:st="on"><st1:city w:st="on">Almeria</st1:city></st1:place></span></p>\r\n            <p style="margin: 0in 0in 0pt;" class="MsoNormal"><st1:city w:st="on"><st1:place w:st="on"><span style="font-size: 10pt; color: black; font-family: Verdana;">Valladolid</span></st1:place></st1:city><span style="font-size: 10pt; color: black; font-family: Verdana;"> <span style="font-weight: bold;">0-3</span> Barca</span></p>\r\n            <p style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-size: 10pt; color: black; font-family: Verdana;">Deportivo <span style="font-weight: bold;">3-1</span> <st1:city w:st="on"><st1:place w:st="on">Bilbao</st1:place></st1:city></span></p>\r\n            <p style="margin: 0in 0in 0pt;" class="MsoNormal"><st1:city w:st="on"><st1:place w:st="on"><span style="font-size: 10pt; color: black; font-family: Verdana;">Gijon</span></st1:place></st1:city><span style="font-size: 10pt; color: black; font-family: Verdana;"> <span>-</span> Racing <span style="font-style: italic;">23h</span><o:p></o:p></span></p>\r\n            <p style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-size: 10pt; color: black; font-family: Verdana;">Tenerife </span><span style="font-size: 10pt; color: black; font-family: Verdana;">-</span><span style="font-size: 10pt; color: black; font-family: Verdana;"> </span><st1:country-region w:st="on"><st1:place w:st="on"><span style="font-size: 10pt; color: black; font-family: Verdana;">Valencia</span></st1:place></st1:country-region><span style="font-size: 10pt; color: black; font-family: Verdana;"> <span style="font-style: italic;">23h</span><o:p></o:p></span></p>\r\n            <p style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-size: 10pt; color: black; font-family: Verdana;">Villarreal <span>-</span> <st1:place w:st="on">Zaragoza</st1:place> <span style="font-style: italic;">23h</span><o:p></o:p></span></p>\r\n            <p style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-size: 10pt; color: black; font-family: Verdana;">Xerez </span><span style="font-size: 10pt; color: black; font-family: Verdana;">-</span><span style="font-size: 10pt; color: black; font-family: Verdana;"> Osasuna <span style="font-style: italic;">23h</span><o:p></o:p></span></p>\r\n            <p style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-size: 10pt; color: black; font-family: Verdana;">Espanyol - <st1:place w:st="on">Mallorca</st1:place> <span style="font-style: italic;">23h</span><o:p></o:p></span></p>\r\n            <p style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-weight: bold;"><span style="font-size: 10pt; color: black; font-style: italic; font-family: Verdana;"><o:p>&nbsp;</o:p></span></span></p>\r\n            <p style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-weight: bold; font-style: italic;"><span style="font-size: 10pt; color: black; font-family: Verdana;">Thứ hai, 25/1</span><span style="color: black;"><o:p></o:p></span></span></p>\r\n            <p style="margin: 0in 0in 0pt;" class="MsoNormal"><st1:city w:st="on"><st1:place w:st="on"><span style="font-size: 10pt; color: black; font-family: Verdana;">Getafe</span></st1:place></st1:city><span style="font-size: 10pt; color: black; font-family: Verdana;"> <span>-</span> Atletico <span style="font-style: italic;">1h</span><o:p></o:p></span></p>\r\n            <p style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-size: 10pt; color: black; font-family: Verdana;">R. Madrid - <st1:city w:st="on"><st1:place w:st="on">Malaga</st1:place></st1:city> <span style="font-style: italic;">3h</span><span><o:p></o:p></span></span></p>\r\n            </td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n</div>\r\n<div style="margin: 0in 0in 0pt;" class="MsoNormal">Nhưng Benzema mới l&agrave; gương mặt g&acirc;y thất vọng nhất bởi trong lần hiếm hoi đ&aacute; ch&iacute;nh, anh c&agrave;ng đ&aacute;nh mất h&igrave;nh ảnh của m&igrave;nh. Ngo&agrave;i một v&agrave;i c&uacute; s&uacute;t thiếu ch&iacute;nh x&aacute;c, tiền đạo người Ph&aacute;p gần như bất lực trong suốt 90 ph&uacute;t. Raul thậm ch&iacute; c&ograve;n sa s&uacute;t hơn v&agrave; &iacute;t khi được HLV Pellegrini trao nhiều cơ hội.</div>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">C&oacute; lẽ, Real Madrid đang cảm thấy nhớ Higuain, người m&agrave; họ coi l&agrave; &ldquo;đồ bỏ&rdquo; từ đầu giải hơn bao giờ hết. Thiếu Higuain, Real mất đi mũi tấn c&ocirc;ng sắc nhọn, di chuyển linh hoạt v&agrave; thường xuy&ecirc;n c&oacute; những pha dứt điểm xuất thần l&agrave;m thay đổi cục diện trận đấu. Ronaldo, Kaka đ&atilde; rất c&oacute; gắng nhưng g&aacute;nh nặng qu&aacute; lớn khiến họ kh&ocirc;ng thể lấp đầy vai tr&ograve; m&agrave; &ldquo;El Pipita&rdquo; để lại.</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Nhưng phải sớm nhất th&igrave; khoảng 10 ng&agrave;y nữa, Higuain mới c&oacute; thể trở lại v&agrave; Real cần phải tiếp tục cuộc sống thiếu &ldquo;số 20&rdquo;. Pellegrini từng tuy&ecirc;n bố &ocirc;ng sẽ t&igrave;m ra phương &aacute;n tấn c&ocirc;ng mới nhưng rốt cuộc, dấu ấn m&agrave; &ocirc;ng để lại c&ugrave;ng d&agrave;n sao đắt tiền vẫn chỉ l&agrave; zero.</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<div style="margin: 0in 0in 0pt;" class="MsoNormal">Một bầu kh&ocirc;ng kh&iacute; u &aacute;m đang bao tr&ugrave;m s&acirc;n Bernabeu, bất chấp việc họ đang giữ vững vị tr&iacute; thứ hai đến hết lượt đi v&agrave; đang tiến bước vững chắc tại Champions League. Nhưng chừng đ&oacute; l&agrave; qu&aacute; &iacute;t với tham vọng &ldquo;decima&rdquo; m&agrave; Perez c&ugrave;ng cộng sự đ&atilde; hứa hẹn trong ng&agrave;y trở lại &ldquo;Nh&agrave; trắng&rdquo;.</div>\r\n<div style="margin: 0in 0in 0pt;" class="MsoNormal">&nbsp;</div>\r\n<div style="margin: 0in 0in 0pt;" class="MsoNormal">&nbsp;</div>\r\n<div align="center" style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-size: 10pt; font-family: Tahoma;"><img width="450" align="center" alt="" style="margin: 5px;" _fl="" src="http://dantri.vcmedia.vn/Uploaded/2010/01/23/Real230110-2.jpg" /><br />\r\nBenzema kh&ocirc;ng thể ho&agrave;n th&agrave;nh vai tr&ograve; thay thế Higuain<br />\r\n</span></div>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Real <st1:state w:st="on">Madrid</st1:state> rất cần một chiến thắng để rửa mặt thất bại tại San Mames v&agrave; việc được tiếp đ&oacute;n <st1:place w:st="on"><st1:city w:st="on">Malaga</st1:city></st1:place> đang xuống dốc th&ecirc; thảm tại Bernabeu đ&ecirc;m nay l&agrave; cơ hội kh&ocirc;ng thể tốt hơn. M&ugrave;a giải trước, Malaga thường thua đậm mỗi khi gi&aacute;p mặt &ldquo;Kền kền trắng&rdquo; n&ecirc;n chắc chắn, 3 điểm kh&ocirc;ng phải l&agrave; mục ti&ecirc;u qu&aacute; kh&oacute; với thầy tr&ograve; HLV Pellegrini.</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Điều quan trọng l&agrave; Real sẽ thắng thế n&agrave;o để xứng với sự kỳ vọng từ c&aacute;c madridista chứ kh&ocirc;ng đơn thuần l&agrave; 3 điểm. Hơn nữa, CLB Ho&agrave;ng gia cũng muốn kh&eacute;p lại lượt đi Liga một c&aacute;ch &ecirc;m đẹp trước khi bước v&agrave;o giai đoạn khốc liệt ở lượt về với kh&ocirc;ng &iacute;t tham vọng.</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Ngo&agrave;i Higuian, Real c&ograve;n thiếu vắng cả Van der Vaart, một cầu thủ cũng đang đạt phong độ cao. Van Nistelrooy th&igrave; đ&atilde; hồi phục, nhưng t&acirc;m tưởng của &ldquo;Van the Man&rdquo; chỉ hướng về West Ham, Tottenham hay <st1:state w:st="on"><st1:place w:st="on">Hamburg</st1:place></st1:state>. B&ecirc;n cạnh đ&oacute;, Drenthe c&ugrave;ng Guti đều bị đau nhẹ n&ecirc;n khả năng ra s&acirc;n vẫn c&ograve;n bỏ ngỏ.</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<div style="margin: 0in 0in 0pt;" class="MsoNormal">Giống như Real, <st1:place w:st="on"><st1:city w:st="on">Malaga</st1:city></st1:place> cũng cần 3 điểm để tho&aacute;t khỏi vị tr&iacute; &ldquo;nguy hiểm&rdquo;. Họ chỉ c&ograve;n hơn đội xếp thứ 18 c&oacute; 1 điểm v&agrave; nguy cơ tụt hạng đang bị treo lơ lửng. Mặc d&ugrave; vậy, HLV Muniz hiểu thực lực đội nh&agrave; n&ecirc;n &ocirc;ng d&aacute;m đặt chỉ ti&ecirc;u trong chuyến h&agrave;nh qu&acirc;n tại Bernabeu.</div>\r\n<div style="margin: 0in 0in 0pt;" class="MsoNormal">&nbsp;</div>\r\n<div style="margin: 0in 0in 0pt;" class="MsoNormal">&nbsp;</div>\r\n<div align="center" style="margin: 0in 0in 0pt;" class="MsoNormal"><span style="font-size: 10pt; font-family: Tahoma;"><br />\r\nMalaga c&oacute; qu&aacute; &iacute;t cơ hội tại Bernabeu đ&ecirc;m nay<br />\r\n</span></div>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Do đ&oacute;, <st1:city w:st="on"><st1:place w:st="on">Malaga</st1:place></st1:city> sẽ v&agrave;o cuộc với t&acirc;m l&yacute; cực kỳ thoải m&aacute;i, yếu tố c&oacute; thể gi&uacute;p họ l&agrave;m n&ecirc;n bất ngờ trước một Real Madrid đang chịu nhiều sức &eacute;p. Tiền vệ trụ cột Duda sẽ trở lại sau &aacute;n treo gi&ograve; nhưng cả Juanito, Baha đều vắng mặt do đ&atilde; nhận đủ thẻ. B&ecirc;n cạnh đ&oacute;, tiền vệ Victor Obinna cũng kh&ocirc;ng thể ra s&acirc;n do đang bận dự CAN 2010 c&ugrave;ng ĐT <st1:country-region w:st="on"><st1:place w:st="on">Nigeria</st1:place></st1:country-region>.</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal">Trội hơn hẳn đối thủ về mọi mặt, lại c&oacute; lợi thế s&acirc;n nh&agrave; n&ecirc;n nếu đ&aacute; đ&uacute;ng sức, Real Madrid ho&agrave;n to&agrave;n c&oacute; thể gi&agrave;nh trọn 3 điểm để tiếp tục cuộc b&aacute;m đuổi Barca. Nhưng trước một <st1:city w:st="on">Malaga</st1:city> đang ở thế đường c&ugrave;ng, Los Blancos kh&ocirc;ng được ph&eacute;p chủ quan, nhất l&agrave; khi họ đang chịu sức &eacute;p lớn sau thất bại cay đắng 0-1 trước <st1:place w:st="on"><st1:city w:st="on">Bilbao</st1:city></st1:place>.</p>\r\n<p style="margin: 0in 0in 0pt;" class="MsoNormal"><o:p>&nbsp;</o:p></p>\r\n</span></p>', 'true', '1264359775', '', '	(Dân trí) - Thất bại cay đắng tại San Mames khiến Real Madrid bị hụt hơi trong cuộc đua cùng Barcelona. Tiếp đón Malaga trên sân nhà đêm nay, đoàn quân HLV Pellegrini không còn con đường nào khác là phải chiến thắng, nếu không muốn rơi vào thảm họa.<br>', '280', 0, '1264357704Real230110-1.jpg', NULL);
INSERT INTO `hdc_product2` VALUES (390, 'Rooney rực sáng giúp MU chiếm ngôi đầu bảng', '269', 'thumb_1264357763.jpg', '', 'true', '<p><span class="bodyContent" id="ctl14_ltrContent">\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="EN-US">Ở trận lượt đi, Rooney cũng đ&atilde; chơi rất hay khi g&oacute;p một b&agrave;n v&agrave; kiến tạo hai đường chuyền th&agrave;nh b&agrave;n trong chiến thắng 3-1 của MU trước <st1:place w:st="on"><st1:placename w:st="on">Hull</st1:placename> <st1:placetype w:st="on">City</st1:placetype></st1:place> ngay tr&ecirc;n s&acirc;n kh&aacute;ch. Trong cuộc t&aacute;i ngộ tối qua, &ldquo;số 10&rdquo; thậm ch&iacute; c&ograve;n c&oacute; m&agrave;n tr&igrave;nh diễn ch&oacute;i s&aacute;ng hơn nữa khi 4 lần s&uacute;t tung lưới thủ th&agrave;nh Boaz Myhill, mang về chiến thắng tưng bừng 4-0 cho &ldquo;Quỷ đỏ&rdquo;.</span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="EN-US"><br />\r\nNhư vậy, với 50 điểm sau 23 trận đ&atilde; đấu, MU đ&atilde; vượt l&ecirc;n chiếm ng&ocirc;i đầu bảng Premier League&nbsp;khi c&ugrave;ng hơn&nbsp;Arsenal v&agrave; Chelsea 2 điểm nhưng đ&atilde; đ&aacute; nhiều trận hơn so với hai đội n&agrave;y. Với c&aacute; nh&acirc;n Rooney, bốn b&agrave;n thắng trong trận đấu n&agrave;y gi&uacute;p tiền đạo tuyển thủ Anh n&acirc;ng số lần lập c&ocirc;ng của anh tại giải Ngoại hạng l&ecirc;n th&agrave;nh 19, tiếp tục dẫn đầu danh s&aacute;ch Vua ph&aacute; lưới m&ugrave;a n&agrave;y.</span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="EN-US"><o:p>&nbsp;</o:p></span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="EN-US">Ngay sau tiếng c&ograve;i khai cuộc, MU đ&atilde; đẩy cao đội h&igrave;nh g&acirc;y sức &eacute;p l&ecirc;n phần s&acirc;n <st1:place w:st="on"><st1:city w:st="on">Hull</st1:city></st1:place>. Kh&ocirc;ng phải chờ đợi qu&aacute; l&acirc;u, đội chủ nh&agrave; đ&atilde; sớm c&oacute; lợi thế với b&agrave;n mở tỷ số ngay ph&uacute;t thứ 8 của Rooney. Sau c&uacute; s&uacute;t xa uy lực của Paul Scholes, thủ m&ocirc;n Myhill đấm b&oacute;ng ra v&agrave; ngay lập tức, Rooney ập v&agrave;o s&uacute;t bồi tung lưới đội kh&aacute;ch.</span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="EN-US"><o:p>&nbsp;</o:p></span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="EN-US">&ldquo;Quỷ đỏ&rdquo; tiếp tục ho&agrave;n to&agrave;n l&agrave;m chủ thế trận ở những ph&uacute;t tiếp theo nhưng lần <st1:place w:st="on"><st1:placename w:st="on">lượt</st1:placename> <st1:placetype w:st="on">Park</st1:placetype></st1:place> ji-Sung rồi hậu vệ mới trở lại Ferdinand bỏ lỡ cơ hội nới rộng c&aacute;ch biệt. D&ugrave; vậy, CĐV MU cũng được phen &ldquo;th&oacute;t tim&rdquo; với pha dứt điểm của Nick Barmby b&ecirc;n ph&iacute;a đội kh&aacute;ch ở ph&uacute;t 18, buộc Van der Sar phải trổ t&agrave;i.</span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="EN-US"><o:p>&nbsp;</o:p></span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="EN-US">Về cuối hiệp 1, MU tăng cường sức &eacute;p với một loạt c&aacute;c t&igrave;nh huống s&oacute;ng gi&oacute; trước khung th&agrave;nh <st1:city w:st="on"><st1:place w:st="on">Hull</st1:place></st1:city>. Ph&uacute;t 39, cầu thủ chạy c&aacute;nh năng nổ Nani căng ngang rất đẹp v&agrave;o v&ograve;ng cấm nhưng Rooney lại dứt điểm chệch đ&iacute;ch khi m&agrave; thủ th&agrave;nh của <st1:city w:st="on"><st1:place w:st="on">Hull</st1:place></st1:city> đ&atilde; ch&ocirc;n ch&acirc;n đứng nh&igrave;n. &Iacute;t ph&uacute;t sau, tiếp tục l&agrave; Nani kiến tạo cơ hội thuận lợi để Owen đối mặt với thủ th&agrave;nh Myhill, tiếc l&agrave; cựu tiền đạo <st1:city w:st="on"><st1:place w:st="on">Newcastle</st1:place></st1:city> kết th&uacute;c qu&aacute; hiền.</span></p>\r\n<div class="MsoNormal" style="margin: 0cm 0cm 0pt" align="center"><span lang="EN-US"><o:p></o:p></span>&nbsp;</div>\r\n<div class="MsoNormal" style="margin: 0cm 0cm 0pt" align="center"><span lang="EN-US"><o:p><img src="http://dantri.vcmedia.vn/Uploaded/2010/01/24/hull-23110.jpg" alt="" /><br />\r\n<span style="font-size: 10pt; font-family: Tahoma">Hull tỏ ra qu&aacute; yếu&nbsp;ớt trước &quot;Quỷ&nbsp;đỏ&quot;<br />\r\n<br />\r\n</span>&nbsp;</o:p></span></div>\r\n<span lang="EN-US">\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="EN-US">Sau giờ nghỉ, đội chủ nh&agrave; vẫn &aacute;p đảo to&agrave;n diện, đặc biệt với sự cơ động của Nani v&agrave; Park ở hai b&ecirc;n c&aacute;nh. MU tiếp tục vượt trội về số cơ hội tạo ra, nhưng điều khiến HLV Alex Ferguson v&agrave; c&aacute;c CĐV tại Old Trafford sốt ruột l&agrave; b&agrave;n thắng tiếp theo cứ li&ecirc;n tục &ldquo;lẩn tr&aacute;nh&rdquo; c&aacute;c ch&acirc;n s&uacute;t chủ nh&agrave;.</span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="EN-US"><o:p>&nbsp;</o:p></span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="EN-US">Kh&ocirc;ng h&agrave;i l&ograve;ng với phong độ của Owen, nh&agrave; cầm qu&acirc;n người <st1:country-region w:st="on"><st1:place w:st="on">Scotland</st1:place></st1:country-region> quyết định thay anh bằng Berbatov. L&atilde;o tướng kỳ cựu Paul Scholes sau đ&oacute; cũng được cho ra nghỉ, tiền vệ trẻ Darron Gibson l&agrave; người thế chỗ.</span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="EN-US"><o:p>&nbsp;</o:p></span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span lang="EN-US">Khi m&agrave; những sự điều chỉnh của Fergie chưa mang lại hiệu quả, <st1:city w:st="on"><st1:place w:st="on">Hull</st1:place></st1:city> ch&uacute;t nữa đ&atilde; c&oacute; b&agrave;n qu&acirc;n b&igrave;nh tỷ số sau pha phản c&ocirc;ng thần tốc. Nhận b&oacute;ng từ </span><span class="txt"><span lang="EN-GB">McShane, cầu thủ v&agrave;o thay người Ghilas khống chế kh&eacute;o l&eacute;o rồi tung c&uacute; s&uacute;t ch&eacute;o g&oacute;c quyết đo&aacute;n. Van der Sar dường như đ&atilde; bất lực nhưng b&oacute;ng lại đi sạt cột dọc trong gang tấc.<o:p></o:p></span></span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span class="txt"><span lang="EN-GB"><o:p>&nbsp;</o:p></span></span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span class="txt"><span lang="EN-GB">Sau bao nỗ lực, MU cuối c&ugrave;ng cũng gia tăng được c&aacute;ch biệt v&agrave; người lập c&ocirc;ng kh&ocirc;ng ai kh&aacute;c vẫn l&agrave; Rooney. Ph&uacute;t 82, c&uacute; đ&aacute; phạt h&agrave;ng r&agrave;o của Nani dội khung gỗ bật ra. Gibson l&agrave; người đoạt lại b&oacute;ng rồi chuyền cho Rooney ở vị tr&iacute; thuận lợi. D&ugrave; một hậu vệ <st1:city w:st="on"><st1:place w:st="on">Hull</st1:place></st1:city> đang bị đau nằm tr&ecirc;n s&acirc;n nhưng &ldquo;số 10&rdquo; vẫn quyết định dứt điểm tung lưới đội kh&aacute;ch, n&acirc;ng tỷ số l&ecirc;n 2-0.<o:p></o:p></span></span></p>\r\n<div class="MsoNormal" style="margin: 0cm 0cm 0pt" align="center"><span class="txt"><span lang="EN-GB"><o:p></o:p></span></span>&nbsp;</div>\r\n<div class="MsoNormal" style="margin: 0cm 0cm 0pt" align="center"><span class="txt"><span lang="EN-GB"><o:p><img src="http://dantri.vcmedia.vn/Uploaded/2010/01/24/roon-23110-s.jpg" alt="" /><br />\r\n<span style="font-size: 10pt; font-family: Tahoma">Rooney thực sự l&agrave; &quot;cơn&nbsp;&aacute;c mộng&quot; với Hull City<br />\r\n<br />\r\n</span>&nbsp;</o:p></span></span></div>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span class="txt"><span lang="EN-GB">B&agrave;n thắng n&agrave;y c&oacute; lẽ khiến tinh thần chiến đấu của c&aacute;c cầu thủ <st1:city w:st="on"><st1:place w:st="on">Hull</st1:place></st1:city> suy sụp, trong khi MU tr&ecirc;n đ&agrave; hưng phấn vẫn kh&ocirc;ng muốn dừng lại. Bốn ph&uacute;t sau, Rooney ho&agrave;n tất c&uacute; hat-trick của m&igrave;nh với pha đ&aacute;nh đầu cận th&agrave;nh dễ d&agrave;ng, sau đường tạt b&oacute;ng của Nani b&ecirc;n c&aacute;nh phải.<o:p></o:p></span></span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span class="txt"><span lang="EN-GB"><o:p>&nbsp;</o:p></span></span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt"><span class="txt"><span lang="EN-GB">Tuy nhi&ecirc;n, m&agrave;n tr&igrave;nh diễn của Rooney vẫn chưa dừng lại ở đ&oacute;. Ph&uacute;t b&ugrave; giờ thứ 3, tuyển thủ Anh n&agrave;y nỗ lực xoay trở d&ugrave; trước mặt anh l&agrave; 3 chiếc &aacute;o v&agrave;ng của Hull, nhanh ch&acirc;n s&uacute;t b&oacute;ng v&agrave;o g&oacute;c gần, ấn định chiến thắng 4-0 cho &ldquo;Quỷ đỏ&rdquo;.<o:p></o:p></span></span></p>\r\n<p class="MsoNormal" style="margin: 0cm 0cm 0pt">&nbsp;</p>\r\n<p>&nbsp;</p>\r\n</span>&nbsp; </span></p>\r\n<p>&nbsp;</p>', 'true', '1264357764', '', '(Dân trí) - Ngôi sao người Anh có một trận đấu tuyệt vời khi mình anh ghi cả 4 bàn thắng giúp “Quỷ đỏ” đè bẹp đội khách Hull City tới 4-0, qua đó tạm thời vượt qua Arsenal và Chelsea để ngự trị ở ngôi đầu bảng.', '280', 0, '1264357763rooney1-23110_130.jpg', NULL);
INSERT INTO `hdc_product2` VALUES (391, 'Đả bại Valladolid, Barca khép lại lượt đi đầy thuyết phục', '269', 'thumb_1264357950.jpg', '', 'true', '<p><span class="bodyContent" id="ctl14_ltrContent">\r\n<div class="MsoNormal" style="margin: 0in 0in 0pt">\r\n<p>H&agrave;nh qu&acirc;n đến s&acirc;n Jose Jorrilla của đội b&oacute;ng ngụp lặn ở vị tr&iacute; thứ 17 tr&ecirc;n BXH Valladolid cộng th&ecirc;m phong độ ấn tượng thời gian gần đ&acirc;y, chiến thắng dường như đang nằm trong tầm tay thầy tr&ograve; Pep Guardiola. Ngo&agrave;i ra chỉ cần c&oacute; điểm trong trận đấu n&agrave;y, g&atilde; khổng lồ xứ <st1:place w:st="on"><st1:state w:st="on">Catalonia</st1:state></st1:place> sẽ kết th&uacute;c lượt đi với vị tr&iacute; đứng đầu BXH v&agrave; chưa hề biết đến thất bại.</p>\r\n<p>&nbsp;</p>\r\n<o:p>&nbsp;</o:p></div>\r\n<div class="MsoNormal" style="margin: 0in 0in 0pt">\r\n<table class="MsoNormalTable" cellspacing="0" cellpadding="0" width="196" align="right" border="1" style="border-right: rgb(0,90,135) 1pt outset; border-top: rgb(0,90,135) 1pt outset; background: whitesmoke; border-left: rgb(0,90,135) 1pt outset; width: 147.25pt; border-bottom: rgb(0,90,135) 1pt outset; moz-background-clip: border; moz-background-origin: padding; moz-background-inline-policy: continuous">\r\n    <tbody>\r\n        <tr>\r\n            <td width="196" style="border-right: rgb(0,90,135) 1pt inset; padding-right: 2.25pt; border-top: rgb(0,90,135) 1pt inset; padding-left: 2.25pt; background: rgb(0,90,135); padding-bottom: 2.25pt; border-left: rgb(0,90,135) 1pt inset; width: 147.25pt; padding-top: 2.25pt; border-bottom: rgb(0,90,135) 1pt inset; moz-background-clip: border; moz-background-origin: padding; moz-background-inline-policy: continuous">\r\n            <p class="msonospacing111111111111111111111" align="center" style="margin: 0in 0in 0pt; text-align: center"><span style="font-weight: bold; font-size: 10pt; color: white; font-family: Verdana">V&ograve;ng&nbsp;19&nbsp;La Liga</span><span style="font-size: 10pt; font-family: Verdana"><o:p></o:p></span></p>\r\n            </td>\r\n        </tr>\r\n        <tr style="height: 129.95pt">\r\n            <td width="196" style="border-right: rgb(0,90,135) 1pt inset; padding-right: 2.25pt; border-top: rgb(0,90,135) 1pt inset; padding-left: 2.25pt; background: none transparent scroll repeat 0% 0%; padding-bottom: 2.25pt; border-left: rgb(0,90,135) 1pt inset; width: 147.25pt; padding-top: 2.25pt; border-bottom: rgb(0,90,135) 1pt inset; height: 129.95pt; moz-background-clip: border; moz-background-origin: padding; moz-background-inline-policy: continuous">\r\n            <p class="MsoNormal" style="margin: 0in 0in 0pt"><span style="font-weight: bold"><span style="font-size: 10pt; color: black; font-style: italic; font-family: Verdana">Chủ nhật, 24/1<o:p></o:p></span></span></p>\r\n            <p class="MsoNormal" style="margin: 0in 0in 0pt"><span style="font-size: 10pt; color: black; font-family: Verdana">Sevilla <span style="font-weight: bold">1-0</span> <st1:city w:st="on"><st1:place w:st="on">Almeria</st1:place></st1:city></span><o:p></o:p></p>\r\n            <p class="MsoNormal" style="margin: 0in 0in 0pt"><st1:city w:st="on"><st1:place w:st="on"><span style="font-size: 10pt; color: black; font-family: Verdana">Valladolid</span></st1:place></st1:city><span style="font-size: 10pt; color: black; font-family: Verdana"> <span style="font-weight: bold">0-3</span> Barca</span><o:p></o:p></p>\r\n            <p class="MsoNormal" style="margin: 0in 0in 0pt"><span style="font-size: 10pt; color: black; font-family: Verdana">Deportivo <span style="font-weight: bold">3-1</span> <st1:city w:st="on"><st1:place w:st="on">Bilbao</st1:place></st1:city></span><o:p></o:p></p>\r\n            <p class="MsoNormal" style="margin: 0in 0in 0pt"><st1:city w:st="on"><st1:place w:st="on"><span style="font-size: 10pt; color: black; font-family: Verdana">Gijon</span></st1:place></st1:city><span style="font-size: 10pt; color: black; font-family: Verdana"> <span>-</span> Racing <span style="font-style: italic">23h</span><o:p></o:p></span></p>\r\n            <p class="MsoNormal" style="margin: 0in 0in 0pt"><span style="font-size: 10pt; color: black; font-family: Verdana">Tenerife </span><span style="font-size: 10pt; color: black; font-family: Verdana">-</span><span style="font-size: 10pt; color: black; font-family: Verdana"> </span><st1:country-region w:st="on"><st1:place w:st="on"><span style="font-size: 10pt; color: black; font-family: Verdana">Valencia</span></st1:place></st1:country-region><span style="font-size: 10pt; color: black; font-family: Verdana"> <span style="font-style: italic">23h</span><o:p></o:p></span></p>\r\n            <p class="MsoNormal" style="margin: 0in 0in 0pt"><span style="font-size: 10pt; color: black; font-family: Verdana">Villarreal <span>-</span> <st1:place w:st="on">Zaragoza</st1:place> <span style="font-style: italic">23h</span><o:p></o:p></span></p>\r\n            <p class="MsoNormal" style="margin: 0in 0in 0pt"><span style="font-size: 10pt; color: black; font-family: Verdana">Xerez </span><span style="font-size: 10pt; color: black; font-family: Verdana">-</span><span style="font-size: 10pt; color: black; font-family: Verdana"> Osasuna <span style="font-style: italic">23h</span><o:p></o:p></span></p>\r\n            <p class="MsoNormal" style="margin: 0in 0in 0pt"><span style="font-size: 10pt; color: black; font-family: Verdana">Espanyol - <st1:place w:st="on">Mallorca</st1:place> <span style="font-style: italic">23h</span><o:p></o:p></span></p>\r\n            <p class="MsoNormal" style="margin: 0in 0in 0pt"><span style="font-weight: bold"><span style="font-size: 10pt; color: black; font-style: italic; font-family: Verdana"><o:p>&nbsp;</o:p></span></span></p>\r\n            <p class="MsoNormal" style="margin: 0in 0in 0pt"><span style="font-weight: bold; font-style: italic"><span style="font-size: 10pt; color: black; font-family: Verdana">Thứ hai, 25/1</span><span style="color: black"><o:p></o:p></span></span></p>\r\n            <p class="MsoNormal" style="margin: 0in 0in 0pt"><st1:city w:st="on"><st1:place w:st="on"><span style="font-size: 10pt; color: black; font-family: Verdana">Getafe</span></st1:place></st1:city><span style="font-size: 10pt; color: black; font-family: Verdana"> <span>-</span> Atletico <span style="font-style: italic">1h</span><o:p></o:p></span></p>\r\n            <p class="MsoNormal" style="margin: 0in 0in 0pt"><span style="font-size: 10pt; color: black; font-family: Verdana">R. Madrid - <st1:city w:st="on"><st1:place w:st="on">Malaga</st1:place></st1:city> <span style="font-style: italic">3h</span><span><o:p></o:p></span></span></p>\r\n            </td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n</div>\r\n<div class="MsoNormal" style="margin: 0in 0in 0pt">Tiếp tục thể hiện một phong độ thuyết phục, Barca dễ d&agrave;ng c&oacute; chiến thắng đậm đ&agrave; 3-0 ngay tr&ecirc;n s&acirc;n của <st1:place w:st="on"><st1:city w:st="on">Valladolid</st1:city></st1:place>. Kh&ocirc;ng mất qu&aacute; nhiều sức với một lối chơi phối hợp nhuần nhuyễn v&agrave; kỹ thuật c&ugrave;ng với c&aacute;c pha lập c&ocirc;ng của Xavi, Alves, Messi, Los Blaugrana đ&atilde; kết th&uacute;c lượt đi một c&aacute;ch kh&ocirc;ng thể tuyệt vời hơn.</div>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt"><o:p>&nbsp;</o:p></p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt">Với chiến thắng n&agrave;y, vị tr&iacute; số 1 tr&ecirc;n BXH của Barca c&agrave;ng được củng cố, khi khoảng c&aacute;ch giữa họ v&agrave; đại k&igrave;nh địch Real Madrid đ&atilde; tạm thời được tăng l&ecirc;n th&agrave;nh 8 điểm. C&ograve;n đối với <st1:place w:st="on"><st1:city w:st="on">Valladolid</st1:city></st1:place> một thất bại trước đội b&oacute;ng lớn như Barca l&agrave; điều c&oacute; thể đo&aacute;n trước v&agrave; nhiệm vụ tr&ecirc;n hết của họ l&agrave; cố gắng tr&aacute;nh xa khu vực cầm đ&egrave;n đỏ.</p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt"><o:p>&nbsp;</o:p></p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt">Tiền vệ trụ Seydou Keita trở lại kịp thời trong trận đấu n&agrave;y khi Sergio Busquets bất ngờ bị chấn thương, c&ugrave;ng Xavi v&agrave; Iniesta kiểm so&aacute;t khu trung tuyến. Tr&ecirc;n h&agrave;ng c&ocirc;ng, Messi được kỳ vọng sẽ tiếp tục thi đấu ch&oacute;i s&aacute;ng khi Ibrahimovic v&agrave; Henry kh&ocirc;ng c&oacute; phong độ thật cao trong thời gian gần đ&acirc;y.</p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt"><o:p>&nbsp;</o:p></p>\r\n<div class="MsoNormal" style="margin: 0in 0in 0pt">Khoảng 20 ph&uacute;t đầu ti&ecirc;n của trận đấu chứng kiến một thế trận kh&aacute; c&acirc;n bằng v&agrave; đ&atilde; c&oacute; nhứng t&igrave;nh huống ăn miếng trả miếng. Đội chủ nh&agrave; chủ động chơi ph&ograve;ng ngự số đ&ocirc;ng v&agrave; &aacute;p s&aacute;t nhằm hạn chế khoảng trống cho c&aacute;c học tr&ograve; của &ocirc;ng Guardiola c&oacute; thể phối hợp. Ch&iacute;nh <st1:place w:st="on"><st1:city w:st="on">Valladolid</st1:city></st1:place> l&agrave; đội tạo được ra được nhiều t&igrave;nh huống s&oacute;ng gi&oacute;.</div>\r\n<div class="MsoNormal" style="margin: 0in 0in 0pt">&nbsp;</div>\r\n<div class="MsoNormal" style="margin: 0in 0in 0pt">&nbsp;</div>\r\n<div class="MsoNormal" style="margin: 0in 0in 0pt" align="center"><span style="font-size: 10pt; font-family: Tahoma"><img src="http://dantri.vcmedia.vn/Uploaded/2010/01/24/Xavi240110-2.jpg" width="450" align="center" _fl="" style="margin: 5px" alt="" /><br />\r\nIbrahimovic đ&atilde; thi đấu kh&aacute; ấn tượng<br />\r\n</span></div>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt"><o:p>&nbsp;</o:p></p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt">Ngay ở ph&uacute;t thứ 2, Canobbio đ&atilde; c&oacute; c&uacute; s&uacute;t phạt kh&aacute; nguy hiểm buộc thủ th&agrave;nh Valdes phải cản ph&aacute; rất vất vả. Đến ph&uacute;t 11 Messi bật tường đẹp mắt với Alves trước khi tung ra c&uacute; sửa l&ograve;ng kỹ thuật nhưng thủ th&agrave;nh <st1:city w:st="on"><st1:place w:st="on">Vila</st1:place></st1:city>r đ&atilde; kịp thời cản ph&aacute;. Kh&ocirc;ng chịu thua k&eacute;m đối thủ, Valdes cũng c&oacute; một pha đổ người đẩy b&oacute;ng rất xuất sắc sau pha tho&aacute;t xuống v&agrave; dứt điểm của Diego Costa.</p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt"><o:p>&nbsp;</o:p></p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt">Ph&uacute;t 20, Xavi ph&aacute;t động một đợt tấn c&ocirc;ng rất nhanh b&ecirc;n c&aacute;nh phải v&agrave; cũng ch&iacute;nh &ldquo;số 6&rdquo; kết th&uacute;c pha b&oacute;ng với c&uacute; v&ocirc; l&ecirc; chuẩn x&aacute;c sau quả tạt của Dani Alves <span style="font-weight: bold">đưa <st1:place w:st="on"><st1:city w:st="on">Barcelona</st1:city></st1:place> vươn l&ecirc;n dẫn trước 1-0. </span>Chỉ đ&uacute;ng 2 ph&uacute;t sau đ&oacute;, cũng từ một đợt tấn c&ocirc;ng nhanh b&ecirc;n c&aacute;nh phải hậu vệ Dani Alves c&oacute; quả tạt b&oacute;ng đi hơi s&acirc;u v&ocirc; t&igrave;nh tạo ra một b&agrave;n thắng đẹp mắt <span style="font-weight: bold">nh&acirc;n đ&ocirc;i c&aacute;ch biệt l&ecirc;n th&agrave;nh 2-0.<o:p></o:p></span></p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt"><span style="font-weight: bold"><o:p>&nbsp;</o:p></span></p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt">Vượt l&ecirc;n dẫn trước nhờ hai b&agrave;n thắng diễn ra kh&aacute; ch&oacute;ng v&aacute;nh, c&aacute;c cầu thủ Barca chủ động chơi chậm v&agrave; giảm nhịp độ của trận đấu. Ph&uacute;t 34, từ đường chuyền thuận lợi của Messi, Ibrahimovic lại khống chế b&oacute;ng hơi thiếu nhạy cảm v&agrave; để cho thủ th&agrave;nh <st1:city w:st="on"><st1:place w:st="on">Vila</st1:place></st1:city>r lao ra bắt gọn. Đ&uacute;ng ph&uacute;t cuối c&ugrave;ng của hiệp 1, Borja c&oacute; pha s&uacute;t phạt rất mạnh, nhưng Valdes đ&atilde; phản xạ rất nhanh đẩy b&oacute;ng ra ngo&agrave;i.</p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt"><o:p>&nbsp;</o:p></p>\r\n<div class="MsoNormal" style="margin: 0in 0in 0pt">Bước sang hiệp đấu thứ 2, tốc độ trận đấu l&agrave; kh&aacute; chậm khi <st1:place w:st="on"><st1:city w:st="on">Barcelona</st1:city></st1:place> chủ động chơi ph&ograve;ng ngự chắc chắn. Tuy nhi&ecirc;n với một đảng cấp vượt trội, đo&agrave;n qu&acirc;n của Pep Guardiola vẫn nắm ho&agrave;n to&agrave;n thế chủ động tr&ecirc;n s&acirc;n. Ph&uacute;t 53, vẫn từ quả tạt b&ecirc;n c&aacute;nh phải của Alves, Henry tung người m&oacute;c b&oacute;ng rất đẹp mắt, tuy nhi&ecirc;n thủ th&agrave;nh của đội chủ nh&agrave; đ&atilde; chơi tỉnh t&aacute;o.</div>\r\n<div class="MsoNormal" style="margin: 0in 0in 0pt">&nbsp;</div>\r\n<div class="MsoNormal" style="margin: 0in 0in 0pt">&nbsp;</div>\r\n<div class="MsoNormal" style="margin: 0in 0in 0pt" align="center"><span style="font-size: 10pt; font-family: Tahoma"><img src="http://dantri.vcmedia.vn/Uploaded/2010/01/24/Xavi240110-3.jpg" width="450" align="center" _fl="" style="margin: 5px" alt="" /><br />\r\nMessi đ&atilde; c&oacute; b&agrave;n thắng thứ 15 tại La Liga năm nay<br />\r\n</span></div>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt"><o:p>&nbsp;</o:p></p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt">Nhưng chỉ hai ph&uacute;t sau, Ibrahimovic c&oacute; đường chuyền rất hợp l&yacute; cho Messi băng v&agrave;o dứt điểm quyết đo&aacute;n tung lưới đối phương <span style="font-weight: bold">đ&agrave;o s&acirc;u khoảng c&aacute;ch l&ecirc;n th&agrave;nh 3-0 cho Los Blaugnara. </span>Ph&uacute;t 64, sau một pha phối hợp rất nhanh v&agrave; đẹp mắt Messi tho&aacute;t xuống tung ra pha dứt điểm đưa b&oacute;ng đi sạt cột dọc.</p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt"><o:p>&nbsp;</o:p></p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt">Đội chủ nh&agrave; gần như đ&atilde; bu&ocirc;ng xu&ocirc;i bởi h&agrave;ng ph&ograve;ng ngự kh&ocirc;ng c&ograve;n chơi quyết liệt như trước, v&agrave; đ&acirc;y l&agrave; cơ hội cho những ng&ocirc;i sao của Barca thể hiện m&igrave;nh. Ph&uacute;t 70, sau nỗ lực đi b&oacute;ng của Messi, tiền đạo Ibrahimovic tung ra một c&uacute; s&uacute;t ch&eacute;o g&oacute;c kh&aacute; mạnh nhưng tiền đạo người Thụy Điển vẫn tỏ ra kh&aacute; v&ocirc; duy&ecirc;n bởi thủ th&agrave;nh <st1:city w:st="on"><st1:place w:st="on">Vila</st1:place></st1:city>r vẫn l&agrave; người chiến thắng cuối c&ugrave;ng.</p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt"><o:p>&nbsp;</o:p></p>\r\n<p class="MsoNormal" style="margin: 0in 0in 0pt">Những ph&uacute;t cuối trận, kh&ocirc;ng c&oacute; qu&aacute; nhiều t&igrave;nh huống s&oacute;ng gi&oacute; được tạo ra khi cả hai đội đều lần lượt r&uacute;t c&aacute;c trụ cột ra khỏi s&acirc;n c&ograve;n c&aacute;c cầu thủ kh&aacute;c chủ động tr&aacute;nh va chạm. Trận đấu kết th&uacute;c với chiến thắng 3-0 kh&aacute; nhẹ nh&agrave;ng của đội kh&aacute;ch <st1:place w:st="on"><st1:city w:st="on">Barcelona</st1:city></st1:place>.</p>\r\n</span></p>', 'true', '1264357951', '', '(Dân trí) - Barcelona đã kết thúc lượt đi La Liga một cách ấn tượng khi đánh bại Valladolid 3-0 tại Jose Zorrilla nhờ các bàn thắng của Xavi, Alves cùng Messi, qua đó nới rộng khoảng cách với đội nhì bảng Real Madrid lên thành 8 điểm...<BR>', '280', 0, '1264357950e15Xavi240110-1.jpg', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_support`
-- 

CREATE TABLE `hdc_support` (
  `id` int(11) NOT NULL auto_increment,
  `nick` varchar(100) character set utf8 default NULL,
  `kind` int(5) default NULL,
  `stt` int(5) default NULL,
  `status` enum('false','true') character set utf8 default 'true',
  `fullname` varchar(255) character set utf8 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

-- 
-- Dumping data for table `hdc_support`
-- 

INSERT INTO `hdc_support` VALUES (17, 'huy_hdc', 2, 2, 'true', 'Quản trị');
INSERT INTO `hdc_support` VALUES (23, 'huy_hdc', 1, 1, 'true', 'Hỗ trợ');

-- --------------------------------------------------------

-- 
-- Table structure for table `hdc_website`
-- 

CREATE TABLE `hdc_website` (
  `id` int(10) NOT NULL auto_increment,
  `title` varchar(200) collate utf8_unicode_ci default NULL,
  `website` varchar(200) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `hdc_website`
-- 

INSERT INTO `hdc_website` VALUES (1, 'Công ty HDC', 'hdc.vn');
INSERT INTO `hdc_website` VALUES (2, 'Báo dân trí', 'dantri.com.vn');
